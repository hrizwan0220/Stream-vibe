package com.streamvibe.tv.ui.theme

import androidx.compose.ui.graphics.Color

val NavyBackground = Color(0xFF070B19)
val NavyCard = Color(0xFF0E172E)
val NavyCardHover = Color(0xFF182444)
val CyanAccent = Color(0xFF00F5D4)
val CyanGlow = Color(0xFF00D2FF)
val PurpleAccent = Color(0xFF8A2BE2)
val PurpleLight = Color(0xFFA855F7)
val AlertRed = Color(0xFFEF4444)
val WhatsAppGreen = Color(0xFF10B981)
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFF94A3B8)
