package com.streamvibe.tv.data.api

import com.streamvibe.tv.data.model.AuthResponse
import com.streamvibe.tv.data.model.LiveCategory
import com.streamvibe.tv.data.model.LiveStream
import retrofit2.http.GET
import retrofit2.http.Query

interface XtreamService {

    @GET("player_api.php")
    suspend fun authenticate(
        @Query("username") username: String,
        @Query("password") password: String
    ): AuthResponse

    @GET("player_api.php")
    suspend fun getLiveCategories(
        @Query("username") username: String,
        @Query("password") password: String,
        @Query("action") action: String = "get_live_categories"
    ): List<LiveCategory>

    @GET("player_api.php")
    suspend fun getLiveStreams(
        @Query("username") username: String,
        @Query("password") password: String,
        @Query("action") action: String = "get_live_streams",
        @Query("category_id") categoryId: String? = null
    ): List<LiveStream>
}
