package com.streamvibe.tv.data.repository

import com.google.gson.GsonBuilder
import com.streamvibe.tv.data.api.XtreamService
import com.streamvibe.tv.data.model.AuthResponse
import com.streamvibe.tv.data.model.LiveCategory
import com.streamvibe.tv.data.model.LiveStream
import com.streamvibe.tv.data.model.UserCredentials
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

class XtreamRepository {

    private fun createService(serverUrl: String): XtreamService {
        var base = serverUrl.trim().removeSuffix("/")
        if (!base.startsWith("http://") && !base.startsWith("https://")) {
            base = "http://$base"
        }
        if (!base.endsWith("/")) {
            base = "$base/"
        }

        val okHttpClient = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .addInterceptor { chain ->
                val request = chain.request().newBuilder()
                    .header("User-Agent", "IPTVSmartersPro/3.1.5.1 (Linux; Android 12; StreamVibeTV)")
                    .build()
                chain.proceed(request)
            }
            .build()

        val gson = GsonBuilder()
            .setLenient()
            .create()

        return Retrofit.Builder()
            .baseUrl(base)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()
            .create(XtreamService::class.java)
    }

    suspend fun authenticate(credentials: UserCredentials): Result<AuthResponse> {
        return try {
            val service = createService(credentials.serverUrl)
            val response = service.authenticate(credentials.username, credentials.password)
            if (response.userInfo == null || response.userInfo.auth == 0) {
                Result.failure(Exception(response.userInfo?.message ?: "Invalid username or password."))
            } else {
                Result.success(response)
            }
        } catch (e: Exception) {
            Result.failure(Exception("Unable to connect to IPTV server: ${e.localizedMessage ?: "Network error"}"))
        }
    }

    suspend fun getCategories(credentials: UserCredentials): Result<List<LiveCategory>> {
        return try {
            val service = createService(credentials.serverUrl)
            val categories = service.getLiveCategories(credentials.username, credentials.password)
            Result.success(categories)
        } catch (e: Exception) {
            Result.failure(Exception("Failed to load categories: ${e.localizedMessage}"))
        }
    }

    suspend fun getStreams(credentials: UserCredentials, categoryId: String? = null): Result<List<LiveStream>> {
        return try {
            val service = createService(credentials.serverUrl)
            val streams = service.getLiveStreams(
                username = credentials.username,
                password = credentials.password,
                categoryId = categoryId
            )
            Result.success(streams)
        } catch (e: Exception) {
            Result.failure(Exception("Failed to load live streams: ${e.localizedMessage}"))
        }
    }
}
