package com.streamvibe.tv.data.model

import com.google.gson.annotations.SerializedName

data class UserCredentials(
    val serverUrl: String,
    val username: String,
    val password: String
)

data class AuthResponse(
    @SerializedName("user_info") val userInfo: UserInfo?,
    @SerializedName("server_info") val serverInfo: ServerInfo?
)

data class UserInfo(
    @SerializedName("username") val username: String?,
    @SerializedName("auth") val auth: Int = 0,
    @SerializedName("status") val status: String = "Active",
    @SerializedName("exp_date") val expDate: String?,
    @SerializedName("active_cons") val activeCons: String?,
    @SerializedName("max_connections") val maxConnections: String?,
    @SerializedName("message") val message: String?
)

data class ServerInfo(
    @SerializedName("url") val url: String?,
    @SerializedName("port") val port: String?,
    @SerializedName("server_protocol") val serverProtocol: String?,
    @SerializedName("timezone") val timezone: String?
)

data class LiveCategory(
    @SerializedName("category_id") val categoryId: String,
    @SerializedName("category_name") val categoryName: String,
    @SerializedName("parent_id") val parentId: Int = 0
)

data class LiveStream(
    @SerializedName("num") val num: Int = 0,
    @SerializedName("name") val name: String,
    @SerializedName("stream_id") val streamId: Int,
    @SerializedName("stream_icon") val streamIcon: String?,
    @SerializedName("epg_channel_id") val epgChannelId: String?,
    @SerializedName("category_id") val categoryId: String,
    @SerializedName("tv_archive") val tvArchive: Int = 0
) {
    fun getStreamPlaybackUrl(credentials: UserCredentials): String {
        var base = credentials.serverUrl.trim().removeSuffix("/")
        if (!base.startsWith("http://") && !base.startsWith("https://")) {
            base = "http://$base"
        }
        return "$base/live/${credentials.username}/${credentials.password}/$streamId.m3u8"
    }
}
