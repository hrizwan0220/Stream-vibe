package com.streamvibe.tv.player

import android.content.Context
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

sealed class PlayerState {
    object Idle : PlayerState()
    object Buffering : PlayerState()
    object Ready : PlayerState()
    object Ended : PlayerState()
    data class Error(val message: String) : PlayerState()
}

@OptIn(UnstableApi::class)
class Media3PlayerManager(private val context: Context) {

    private var exoPlayer: ExoPlayer? = null
    private val _playbackState = MutableStateFlow<PlayerState>(PlayerState.Idle)
    val playbackState: StateFlow<PlayerState> = _playbackState

    fun initializePlayer(): ExoPlayer {
        if (exoPlayer == null) {
            val loadControl = DefaultLoadControl.Builder()
                .setBufferDurationsMs(
                    2000,  // minBufferMs
                    8000,  // maxBufferMs
                    1000,  // bufferForPlaybackMs
                    1500   // bufferForPlaybackAfterRebufferMs
                )
                .build()

            exoPlayer = ExoPlayer.Builder(context)
                .setLoadControl(loadControl)
                .setWakeMode(C.WAKE_MODE_NETWORK)
                .build()
                .apply {
                    playWhenReady = true
                    addListener(object : Player.Listener {
                        override fun onPlaybackStateChanged(state: Int) {
                            when (state) {
                                Player.STATE_IDLE -> _playbackState.value = PlayerState.Idle
                                Player.STATE_BUFFERING -> _playbackState.value = PlayerState.Buffering
                                Player.STATE_READY -> _playbackState.value = PlayerState.Ready
                                Player.STATE_ENDED -> _playbackState.value = PlayerState.Ended
                            }
                        }

                        override fun onPlayerError(error: PlaybackException) {
                            _playbackState.value = PlayerState.Error(
                                error.localizedMessage ?: "Stream playback failed. Server may be offline."
                            )
                        }
                    })
                }
        }
        return exoPlayer!!
    }

    fun playStream(streamUrl: String) {
        val player = initializePlayer()
        val uri = Uri.parse(streamUrl)

        val dataSourceFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("IPTVSmartersPro/3.1.5.1 (Linux; Android 12; StreamVibeTV)")
            .setConnectTimeoutMs(12000)
            .setReadTimeoutMs(20000)
            .setAllowCrossProtocolRedirects(true)

        val mediaSource: MediaSource = if (streamUrl.contains(".m3u8")) {
            HlsMediaSource.Factory(dataSourceFactory)
                .setAllowChunklessPreparation(true)
                .createMediaSource(MediaItem.fromUri(uri))
        } else {
            ProgressiveMediaSource.Factory(dataSourceFactory)
                .createMediaSource(MediaItem.fromUri(uri))
        }

        player.setMediaSource(mediaSource)
        player.prepare()
        player.play()
    }

    fun release() {
        exoPlayer?.release()
        exoPlayer = null
        _playbackState.value = PlayerState.Idle
    }
}
