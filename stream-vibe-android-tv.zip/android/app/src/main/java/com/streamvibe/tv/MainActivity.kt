package com.streamvibe.tv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import com.streamvibe.tv.data.model.LiveCategory
import com.streamvibe.tv.data.model.LiveStream
import com.streamvibe.tv.data.model.UserCredentials
import com.streamvibe.tv.data.repository.XtreamRepository
import com.streamvibe.tv.data.storage.SecureCredentialsManager
import com.streamvibe.tv.ui.screens.*
import com.streamvibe.tv.ui.theme.StreamVibeTheme
import kotlinx.coroutines.launch

sealed class Screen {
    object Splash : Screen()
    object Login : Screen()
    object Main : Screen()
    data class Player(val channel: LiveStream) : Screen()
    data class Expired(val username: String) : Screen()
}

class MainActivity : ComponentActivity() {

    private val repository = XtreamRepository()
    private lateinit var credentialsManager: SecureCredentialsManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        credentialsManager = SecureCredentialsManager(this)

        setContent {
            StreamVibeTheme {
                val coroutineScope = rememberCoroutineScope()
                var currentScreen by remember { mutableStateOf<Screen>(Screen.Splash) }
                var activeCredentials by remember { mutableStateOf<UserCredentials?>(null) }
                var categories by remember { mutableStateOf<List<LiveCategory>>(emptyList()) }
                var channels by remember { mutableStateOf<List<LiveStream>>(emptyList()) }
                var selectedCategoryId by remember { mutableStateOf<String?>("all") }
                var isLoading by remember { mutableStateOf(false) }
                var errorMessage by remember { mutableStateOf<String?>(null) }

                fun performLogin(credentials: UserCredentials) {
                    isLoading = true
                    errorMessage = null
                    coroutineScope.launch {
                        val authResult = repository.authenticate(credentials)
                        authResult.onSuccess { response ->
                            val user = response.userInfo
                            if (user?.status?.equals("Expired", ignoreCase = true) == true) {
                                isLoading = false
                                currentScreen = Screen.Expired(credentials.username)
                                return@launch
                            }

                            credentialsManager.saveCredentials(credentials)
                            activeCredentials = credentials

                            // Load Categories and streams
                            val catResult = repository.getCategories(credentials)
                            categories = catResult.getOrDefault(listOf(LiveCategory("all", "All Channels")))

                            val streamResult = repository.getStreams(credentials)
                            channels = streamResult.getOrDefault(emptyList())

                            isLoading = false
                            currentScreen = Screen.Main
                        }.onFailure { error ->
                            isLoading = false
                            errorMessage = error.localizedMessage ?: "Login failed. Check server and credentials."
                        }
                    }
                }

                when (val screen = currentScreen) {
                    is Screen.Splash -> {
                        SplashScreen(
                            onNavigateNext = {
                                val saved = credentialsManager.getCredentials()
                                if (saved != null) {
                                    performLogin(saved)
                                } else {
                                    currentScreen = Screen.Login
                                }
                            }
                        )
                    }

                    is Screen.Login -> {
                        LoginScreen(
                            onLoginSubmit = { creds -> performLogin(creds) },
                            isLoading = isLoading,
                            errorMessage = errorMessage
                        )
                    }

                    is Screen.Main -> {
                        MainTvScreen(
                            categories = categories,
                            channels = channels,
                            selectedCategoryId = selectedCategoryId,
                            onSelectCategory = { catId ->
                                selectedCategoryId = catId
                                coroutineScope.launch {
                                    activeCredentials?.let { creds ->
                                        val filterId = if (catId == "all") null else catId
                                        val res = repository.getStreams(creds, filterId)
                                        channels = res.getOrDefault(emptyList())
                                    }
                                }
                            },
                            onSelectChannel = { channel ->
                                currentScreen = Screen.Player(channel)
                            },
                            onLogout = {
                                credentialsManager.clearCredentials()
                                activeCredentials = null
                                currentScreen = Screen.Login
                            }
                        )
                    }

                    is Screen.Player -> {
                        activeCredentials?.let { creds ->
                            PlayerScreen(
                                channel = screen.channel,
                                credentials = creds,
                                onBackToGuide = { currentScreen = Screen.Main }
                            )
                        } ?: run {
                            currentScreen = Screen.Login
                        }
                    }

                    is Screen.Expired -> {
                        SubscriptionExpiredScreen(
                            username = screen.username,
                            onRelogin = {
                                credentialsManager.clearCredentials()
                                currentScreen = Screen.Login
                            }
                        )
                    }
                }
            }
        }
    }
}
