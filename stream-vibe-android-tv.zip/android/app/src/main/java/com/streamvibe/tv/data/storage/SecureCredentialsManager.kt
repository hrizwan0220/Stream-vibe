package com.streamvibe.tv.data.storage

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.streamvibe.tv.data.model.UserCredentials

/**
 * Secure credential storage using Android EncryptedSharedPreferences.
 * Ensures customer credentials entered at runtime are encrypted on disk
 * and NEVER hardcoded into the application codebase.
 */
class SecureCredentialsManager(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val sharedPreferences = try {
        EncryptedSharedPreferences.create(
            context,
            "stream_vibe_secure_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        // Fallback for devices without hardware keystore
        context.getSharedPreferences("stream_vibe_fallback_prefs", Context.MODE_PRIVATE)
    }

    companion object {
        private const val KEY_SERVER_URL = "xtream_server_url"
        private const val KEY_USERNAME = "xtream_username"
        private const val KEY_PASSWORD = "xtream_password"
    }

    fun saveCredentials(credentials: UserCredentials) {
        sharedPreferences.edit()
            .putString(KEY_SERVER_URL, credentials.serverUrl.trim())
            .putString(KEY_USERNAME, credentials.username.trim())
            .putString(KEY_PASSWORD, credentials.password.trim())
            .apply()
    }

    fun getCredentials(): UserCredentials? {
        val server = sharedPreferences.getString(KEY_SERVER_URL, null)
        val user = sharedPreferences.getString(KEY_USERNAME, null)
        val pass = sharedPreferences.getString(KEY_PASSWORD, null)

        if (!server.isNullOrBlank() && !user.isNullOrBlank() && !pass.isNullOrBlank()) {
            return UserCredentials(server, user, pass)
        }
        return null
    }

    fun clearCredentials() {
        sharedPreferences.edit()
            .remove(KEY_SERVER_URL)
            .remove(KEY_USERNAME)
            .remove(KEY_PASSWORD)
            .apply()
    }
}
