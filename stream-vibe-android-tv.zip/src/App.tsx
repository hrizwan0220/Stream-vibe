/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { 
  XtreamCredentials, 
  XtreamUserInfo, 
  XtreamCategory, 
  XtreamLiveStream 
} from './types/xtream';
import { 
  authenticateXtream, 
  getLiveCategories, 
  getLiveStreams, 
  DEMO_CATEGORIES, 
  DEMO_STREAMS 
} from './services/xtreamApi';
import { SplashScreen } from './components/SplashScreen';
import { LoginScreen } from './components/LoginScreen';
import { ChannelGuide } from './components/ChannelGuide';
import { LivePlayer } from './components/LivePlayer';
import { SubscriptionExpiredScreen } from './components/SubscriptionExpiredScreen';
import { TvRemoteControl } from './components/TvRemoteControl';
import { AndroidProjectExporter } from './components/AndroidProjectExporter';
import { tvAudio } from './utils/tvAudio';
import { Tv, Radio, HelpCircle } from 'lucide-react';

export default function App() {
  // Navigation & screens
  const [currentScreen, setCurrentScreen] = useState<'splash' | 'login' | 'guide' | 'player'>('splash');
  const [showExpiredModal, setShowExpiredModal] = useState<boolean>(false);
  const [showAndroidExport, setShowAndroidExport] = useState<boolean>(false);
  const [showRemoteControl, setShowRemoteControl] = useState<boolean>(true);

  // Auth & Provider data
  const [credentials, setCredentials] = useState<XtreamCredentials | null>(null);
  const [userInfo, setUserInfo] = useState<XtreamUserInfo | null>(null);
  const [categories, setCategories] = useState<XtreamCategory[]>([]);
  const [channels, setChannels] = useState<XtreamLiveStream[]>([]);
  const [activeCategoryId, setActiveCategoryId] = useState<string>('all');
  const [activeChannel, setActiveChannel] = useState<XtreamLiveStream | null>(null);

  // Status & errors
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Player controls
  const [isFullScreen, setIsFullScreen] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(false);

  // User preferences (Favorites)
  const [favorites, setFavorites] = useState<number[]>(() => {
    try {
      const saved = localStorage.getItem('stream_vibe_favs');
      return saved ? JSON.parse(saved) : [101, 103];
    } catch {
      return [101, 103];
    }
  });

  // TV D-Pad Focus indices
  const [focusedSection, setFocusedSection] = useState<'categories' | 'channels'>('channels');
  const [focusedIndex, setFocusedIndex] = useState<number>(0);

  // Save favorites
  const toggleFavorite = (streamId: number) => {
    setFavorites((prev) => {
      const next = prev.includes(streamId) ? prev.filter((id) => id !== streamId) : [...prev, streamId];
      try {
        localStorage.setItem('stream_vibe_favs', JSON.stringify(next));
      } catch {}
      return next;
    });
  };

  // Perform Xtream Login
  const handleLogin = async (creds: XtreamCredentials, remember: boolean) => {
    setIsLoading(true);
    setErrorMessage(null);

    try {
      const authData = await authenticateXtream(creds);
      const user = authData.user_info;

      // Check if account status is expired or unauthorized
      const isExpiredStatus = user.status?.toLowerCase() === 'expired';
      const isExpiredDate = user.exp_date && Number(user.exp_date) > 0 && Number(user.exp_date) < Math.floor(Date.now() / 1000);

      if (isExpiredStatus || isExpiredDate) {
        setUserInfo(user);
        setCredentials(creds);
        setIsLoading(false);
        setShowExpiredModal(true);
        return;
      }

      setUserInfo(user);
      setCredentials(creds);

      if (remember) {
        try {
          localStorage.setItem('stream_vibe_saved_creds', JSON.stringify(creds));
        } catch {}
      } else {
        localStorage.removeItem('stream_vibe_saved_creds');
      }

      // Load Categories
      const loadedCategories = await getLiveCategories(creds);
      setCategories(loadedCategories);

      // Load Channels
      const loadedChannels = await getLiveStreams(creds);
      setChannels(loadedChannels);

      if (loadedChannels.length > 0) {
        setActiveChannel(loadedChannels[0]);
      }

      setIsLoading(false);
      setCurrentScreen('guide');
    } catch (err: any) {
      setIsLoading(false);
      setErrorMessage(err.message || 'Login failed. Please check your credentials and server URL.');
    }
  };

  // Quick Demo Channels Mode
  const handleQuickDemo = async () => {
    const demoCreds: XtreamCredentials = {
      serverUrl: 'http://demo.streamvibe.tv:8080',
      username: 'demo',
      password: 'demo_password',
      serverName: 'Stream Vibe Official Demo',
    };
    await handleLogin(demoCreds, false);
  };

  // Quick Expired Subscription Test Mode
  const handleQuickExpiredTest = async () => {
    const expiredCreds: XtreamCredentials = {
      serverUrl: 'http://iptv-server.provider.net:8080',
      username: 'expired',
      password: 'test_password',
    };
    await handleLogin(expiredCreds, false);
  };

  // Switch Category
  const handleSelectCategory = async (catId: string) => {
    setActiveCategoryId(catId);
    setFocusedIndex(0);
    if (!credentials) return;

    try {
      const filtered = await getLiveStreams(credentials, catId);
      setChannels(filtered);
      if (filtered.length > 0) {
        setActiveChannel(filtered[0]);
      }
    } catch (e: any) {
      setErrorMessage(e.message || 'Failed to switch category');
    }
  };

  // Select Channel
  const handleSelectChannel = (channel: XtreamLiveStream) => {
    setActiveChannel(channel);
  };

  // Open Full Player
  const handleOpenPlayer = (channel: XtreamLiveStream) => {
    setActiveChannel(channel);
    setCurrentScreen('player');
    setIsFullScreen(true);
  };

  // Channel Zapping (Next / Prev)
  const handleNextChannel = () => {
    if (channels.length === 0) return;
    const currentIdx = channels.findIndex((c) => c.stream_id === activeChannel?.stream_id);
    const nextIdx = (currentIdx + 1) % channels.length;
    setActiveChannel(channels[nextIdx]);
  };

  const handlePrevChannel = () => {
    if (channels.length === 0) return;
    const currentIdx = channels.findIndex((c) => c.stream_id === activeChannel?.stream_id);
    const prevIdx = (currentIdx - 1 + channels.length) % channels.length;
    setActiveChannel(channels[prevIdx]);
  };

  // Logout
  const handleLogout = () => {
    try {
      localStorage.removeItem('stream_vibe_saved_creds');
    } catch {}
    setCredentials(null);
    setUserInfo(null);
    setChannels([]);
    setActiveChannel(null);
    setShowExpiredModal(false);
    setCurrentScreen('login');
  };

  // Toggle FullScreen
  const handleToggleFullScreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsFullScreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullScreen(false);
    }
  };

  // D-Pad Directional Navigation
  const handleDpadNavigation = useCallback(
    (direction: 'up' | 'down' | 'left' | 'right') => {
      if (currentScreen === 'player') {
        if (direction === 'up' || direction === 'right') handleNextChannel();
        if (direction === 'down' || direction === 'left') handlePrevChannel();
        return;
      }

      if (currentScreen !== 'guide') return;

      if (direction === 'left') {
        setFocusedSection('categories');
      } else if (direction === 'right') {
        setFocusedSection('channels');
      } else if (direction === 'up') {
        setFocusedIndex((prev) => Math.max(0, prev - 1));
      } else if (direction === 'down') {
        const max = focusedSection === 'categories' ? categories.length : channels.length - 1;
        setFocusedIndex((prev) => Math.min(max, prev + 1));
      }
    },
    [currentScreen, categories.length, channels.length, focusedSection]
  );

  // D-Pad Select / OK
  const handleDpadSelect = useCallback(() => {
    if (currentScreen === 'guide') {
      if (focusedSection === 'categories') {
        if (focusedIndex === 0) {
          handleSelectCategory('all');
        } else if (categories[focusedIndex - 1]) {
          handleSelectCategory(categories[focusedIndex - 1].category_id);
        }
      } else if (focusedSection === 'channels' && channels[focusedIndex]) {
        handleOpenPlayer(channels[focusedIndex]);
      }
    }
  }, [currentScreen, focusedSection, focusedIndex, categories, channels]);

  // D-Pad Back
  const handleDpadBack = useCallback(() => {
    if (showExpiredModal) {
      setShowExpiredModal(false);
      return;
    }
    if (showAndroidExport) {
      setShowAndroidExport(false);
      return;
    }
    if (currentScreen === 'player') {
      setCurrentScreen('guide');
      setIsFullScreen(false);
      return;
    }
    if (focusedSection === 'channels') {
      setFocusedSection('categories');
    }
  }, [currentScreen, showExpiredModal, showAndroidExport, focusedSection]);

  // Global Keyboard listener for physical TV Remote / Keyboard keys
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept typing in inputs
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) {
        return;
      }

      switch (e.key) {
        case 'ArrowUp':
          e.preventDefault();
          tvAudio.playClick();
          handleDpadNavigation('up');
          break;
        case 'ArrowDown':
          e.preventDefault();
          tvAudio.playClick();
          handleDpadNavigation('down');
          break;
        case 'ArrowLeft':
          e.preventDefault();
          tvAudio.playClick();
          handleDpadNavigation('left');
          break;
        case 'ArrowRight':
          e.preventDefault();
          tvAudio.playClick();
          handleDpadNavigation('right');
          break;
        case 'Enter':
          e.preventDefault();
          tvAudio.playSelect();
          handleDpadSelect();
          break;
        case 'Escape':
        case 'Backspace':
          e.preventDefault();
          tvAudio.playBack();
          handleDpadBack();
          break;
        case 'f':
        case 'F':
          e.preventDefault();
          handleToggleFullScreen();
          break;
        case 'm':
        case 'M':
          e.preventDefault();
          setIsMuted((prev) => !prev);
          break;
        default:
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleDpadNavigation, handleDpadSelect, handleDpadBack]);

  // Auto-check saved credentials on app launch
  const handleSplashFinish = () => {
    try {
      const saved = localStorage.getItem('stream_vibe_saved_creds');
      if (saved) {
        const creds = JSON.parse(saved);
        if (creds?.serverUrl && creds?.username && creds?.password) {
          handleLogin(creds, true);
          return;
        }
      }
    } catch {}
    setCurrentScreen('login');
  };

  return (
    <div className="relative w-screen h-screen bg-[#070B19] text-white overflow-hidden font-sans">
      {/* Screen 1: Splash Screen */}
      {currentScreen === 'splash' && (
        <SplashScreen onFinish={handleSplashFinish} />
      )}

      {/* Screen 2: Login Screen */}
      {currentScreen === 'login' && (
        <LoginScreen
          onLogin={handleLogin}
          isLoading={isLoading}
          errorMessage={errorMessage}
          onClearError={() => setErrorMessage(null)}
          onQuickDemo={handleQuickDemo}
          onQuickExpiredTest={handleQuickExpiredTest}
        />
      )}

      {/* Screen 3: Channel Guide (Main TV Screen) */}
      {currentScreen === 'guide' && (
        <ChannelGuide
          categories={categories}
          channels={channels}
          activeCategoryId={activeCategoryId}
          onSelectCategory={handleSelectCategory}
          activeChannel={activeChannel}
          onSelectChannel={handleSelectChannel}
          onOpenPlayer={handleOpenPlayer}
          userInfo={userInfo}
          credentials={credentials}
          onLogout={handleLogout}
          onOpenAndroidExport={() => setShowAndroidExport(true)}
          onTriggerExpiredModal={() => setShowExpiredModal(true)}
          focusedIndex={focusedIndex}
          focusedSection={focusedSection}
          favorites={favorites}
          onToggleFavorite={toggleFavorite}
        />
      )}

      {/* Screen 4: Fullscreen Live Video Player */}
      {currentScreen === 'player' && activeChannel && (
        <LivePlayer
          channel={activeChannel}
          credentials={credentials}
          onNextChannel={handleNextChannel}
          onPrevChannel={handlePrevChannel}
          onClosePlayer={() => {
            setCurrentScreen('guide');
            setIsFullScreen(false);
          }}
          isFullScreen={isFullScreen}
          onToggleFullScreen={handleToggleFullScreen}
        />
      )}

      {/* Subscription Expired Modal / Screen */}
      {showExpiredModal && (
        <SubscriptionExpiredScreen
          username={userInfo?.username || credentials?.username || 'Customer'}
          expiryDate={userInfo?.exp_date}
          onRelogin={handleLogout}
          onUseDemoMode={() => {
            setShowExpiredModal(false);
            handleQuickDemo();
          }}
        />
      )}

      {/* Android Project & APK Build Modal */}
      {showAndroidExport && (
        <AndroidProjectExporter
          isOpen={showAndroidExport}
          onClose={() => setShowAndroidExport(false)}
        />
      )}

      {/* TV Remote Control Floating Widget */}
      {currentScreen !== 'splash' && (
        <>
          <TvRemoteControl
            isOpen={showRemoteControl}
            onClose={() => setShowRemoteControl(false)}
            onNavigate={handleDpadNavigation}
            onSelect={handleDpadSelect}
            onBack={handleDpadBack}
            onHome={() => {
              if (currentScreen === 'player') setCurrentScreen('guide');
            }}
            isFullScreen={isFullScreen}
            onToggleFullScreen={handleToggleFullScreen}
            isMuted={isMuted}
            onToggleMute={() => setIsMuted((prev) => !prev)}
            onNextChannel={handleNextChannel}
            onPrevChannel={handlePrevChannel}
            onShowExpiredModal={() => setShowExpiredModal(true)}
          />

          {/* Collapsed Remote Toggle Button */}
          {!showRemoteControl && (
            <button
              onClick={() => {
                tvAudio.playClick();
                setShowRemoteControl(true);
              }}
              className="fixed bottom-6 right-6 z-40 p-3.5 rounded-full bg-gradient-to-tr from-cyan-500 to-purple-600 text-slate-950 font-bold shadow-2xl shadow-cyan-500/40 hover:scale-105 active:scale-95 transition-all flex items-center gap-2 group"
              title="Open TV Remote Control"
            >
              <Tv className="w-5 h-5" />
              <span className="text-xs font-black uppercase tracking-wider pr-1">TV Remote</span>
            </button>
          )}
        </>
      )}
    </div>
  );
}
