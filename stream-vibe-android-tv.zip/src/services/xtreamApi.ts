import { XtreamAuthResponse, XtreamCategory, XtreamCredentials, XtreamLiveStream } from '../types/xtream';

/**
 * Normalizes user-entered server URL (trims slashes, ensures http/https scheme)
 */
export function normalizeServerUrl(rawUrl: string): string {
  let url = rawUrl.trim();
  if (!url) return '';
  if (!/^https?:\/\//i.test(url)) {
    url = `http://${url}`;
  }
  return url.replace(/\/+$/, '');
}

/**
 * Helper to fetch with proxy fallback to handle browser CORS and mixed content.
 * Native Android TV apps bypass CORS automatically using OkHttp.
 */
async function fetchWithProxy(targetUrl: string): Promise<Response> {
  try {
    // First try direct fetch
    const directRes = await fetch(targetUrl, {
      headers: {
        'Accept': 'application/json, text/plain, */*',
      },
    });
    if (directRes.ok) return directRes;
  } catch {
    // Direct fetch failed (likely CORS or Mixed Content), fall back to dev proxy
  }

  // Use dev proxy endpoint
  const proxyUrl = `/api/proxy?url=${encodeURIComponent(targetUrl)}`;
  const proxyRes = await fetch(proxyUrl);
  if (!proxyRes.ok) {
    const errorText = await proxyRes.text().catch(() => 'Network response was not ok');
    throw new Error(`Failed to connect to IPTV server (${proxyRes.status}): ${errorText}`);
  }
  return proxyRes;
}

/**
 * High-quality verified legal live HLS streams for testing and demo mode
 */
export const DEMO_CATEGORIES: XtreamCategory[] = [
  { category_id: '1', category_name: '★ Top Live Channels' },
  { category_id: '2', category_name: 'News & Info HD' },
  { category_id: '3', category_name: 'Sports & Action' },
  { category_id: '4', category_name: 'Entertainment & Movies' },
  { category_id: '5', category_name: 'Science & Documentary' },
  { category_id: '6', category_name: 'Music & Vibes' },
];

export const DEMO_STREAMS: XtreamLiveStream[] = [
  {
    num: 1,
    name: 'Bloomberg TV USA HD',
    stream_id: 101,
    stream_icon: 'https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?w=300&auto=format&fit=crop&q=80',
    category_id: '2',
    categoryName: 'News & Info HD',
    customStreamUrl: 'https://live-bloomberg-us.global.ssl.fastly.net/bloomberg_us/index.m3u8',
  },
  {
    num: 2,
    name: 'NASA TV - Public Live Stream',
    stream_id: 102,
    stream_icon: 'https://images.unsplash.com/photo-1614728894747-a83421e2b9c9?w=300&auto=format&fit=crop&q=80',
    category_id: '5',
    categoryName: 'Science & Documentary',
    customStreamUrl: 'https://ntv1.akamaized.net/hls/live/2014075/NASA-NTV1-HLS/master.m3u8',
  },
  {
    num: 3,
    name: 'Red Bull TV Extreme Sports',
    stream_id: 103,
    stream_icon: 'https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=300&auto=format&fit=crop&q=80',
    category_id: '3',
    categoryName: 'Sports & Action',
    customStreamUrl: 'https://rbmn-live.akamaized.net/hls/live/590964/BoRB-AT/master.m3u8',
  },
  {
    num: 4,
    name: 'DW News English HD',
    stream_id: 104,
    stream_icon: 'https://images.unsplash.com/photo-1585829365295-ab7cd400c167?w=300&auto=format&fit=crop&q=80',
    category_id: '2',
    categoryName: 'News & Info HD',
    customStreamUrl: 'https://dwamdstream102.akamaized.net/hls/live/2015525/dwstream102/index.m3u8',
  },
  {
    num: 5,
    name: 'France 24 English Global Live',
    stream_id: 105,
    stream_icon: 'https://images.unsplash.com/photo-1505373877841-8d25f7d46678?w=300&auto=format&fit=crop&q=80',
    category_id: '2',
    categoryName: 'News & Info HD',
    customStreamUrl: 'https://stream.france24.com/hls/live/2037084/F24_EN_LO_HLS/master.m3u8',
  },
  {
    num: 6,
    name: 'Euronews International HD',
    stream_id: 106,
    stream_icon: 'https://images.unsplash.com/photo-1495020689067-958852a7765e?w=300&auto=format&fit=crop&q=80',
    category_id: '2',
    categoryName: 'News & Info HD',
    customStreamUrl: 'https://euronews-euronews-world-1-au.samsung.wurl.tv/manifest/playlist.m3u8',
  },
  {
    num: 7,
    name: 'Cinema Classic Retro Movies',
    stream_id: 107,
    stream_icon: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=300&auto=format&fit=crop&q=80',
    category_id: '4',
    categoryName: 'Entertainment & Movies',
    customStreamUrl: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
  },
  {
    num: 8,
    name: 'Big Buck Bunny 4K Showcase',
    stream_id: 108,
    stream_icon: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=300&auto=format&fit=crop&q=80',
    category_id: '4',
    categoryName: 'Entertainment & Movies',
    customStreamUrl: 'https://test-streams.mux.dev/test_001/stream.m3u8',
  },
  {
    num: 9,
    name: 'Nature & Wildlife 24/7 Relax',
    stream_id: 109,
    stream_icon: 'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=300&auto=format&fit=crop&q=80',
    category_id: '5',
    categoryName: 'Science & Documentary',
    customStreamUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
  },
  {
    num: 10,
    name: 'Stream Vibe Club Lounge',
    stream_id: 110,
    stream_icon: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300&auto=format&fit=crop&q=80',
    category_id: '6',
    categoryName: 'Music & Vibes',
    customStreamUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
  },
];

/**
 * Authenticates user credentials with Xtream Codes API
 */
export async function authenticateXtream(credentials: XtreamCredentials): Promise<XtreamAuthResponse> {
  const server = normalizeServerUrl(credentials.serverUrl);
  if (!server) {
    throw new Error('Please enter a valid Server URL (e.g. http://your-iptv-server.com:8080)');
  }
  if (!credentials.username.trim() || !credentials.password.trim()) {
    throw new Error('Username and Password cannot be empty.');
  }

  // Handle local demo server mode
  if (credentials.username.toLowerCase() === 'demo' || server.includes('demo.streamvibe')) {
    return {
      user_info: {
        username: credentials.username,
        auth: 1,
        status: 'Active',
        exp_date: (Math.floor(Date.now() / 1000) + 86400 * 365).toString(),
        active_cons: '1',
        max_connections: '3',
        is_trial: '0',
      },
      server_info: {
        url: server,
        port: '8080',
        server_protocol: 'http',
        timezone: 'UTC',
      },
    };
  }

  // Handle local expired simulation mode
  if (credentials.username.toLowerCase() === 'expired') {
    return {
      user_info: {
        username: credentials.username,
        auth: 1,
        status: 'Expired',
        exp_date: (Math.floor(Date.now() / 1000) - 86400 * 5).toString(),
        active_cons: '0',
        max_connections: '1',
      },
      server_info: {
        url: server,
        port: '8080',
        server_protocol: 'http',
      },
    };
  }

  const endpoint = `${server}/player_api.php?username=${encodeURIComponent(credentials.username)}&password=${encodeURIComponent(credentials.password)}`;
  
  try {
    const response = await fetchWithProxy(endpoint);
    const data = await response.json();

    if (!data || typeof data !== 'object') {
      throw new Error('Invalid response received from Xtream Codes server.');
    }

    if (!data.user_info || data.user_info.auth === 0) {
      throw new Error(data.user_info?.message || 'Authentication failed: Incorrect username or password.');
    }

    return data as XtreamAuthResponse;
  } catch (error: any) {
    if (error.message?.includes('Failed to fetch') || error.message?.includes('NetworkError')) {
      throw new Error('Network error: Unable to connect to the IPTV server. Please check the URL, port, and your internet connection.');
    }
    throw error;
  }
}

/**
 * Fetches Live Categories
 */
export async function getLiveCategories(credentials: XtreamCredentials): Promise<XtreamCategory[]> {
  const server = normalizeServerUrl(credentials.serverUrl);
  if (credentials.username.toLowerCase() === 'demo' || server.includes('demo.streamvibe')) {
    return DEMO_CATEGORIES;
  }

  const endpoint = `${server}/player_api.php?username=${encodeURIComponent(credentials.username)}&password=${encodeURIComponent(credentials.password)}&action=get_live_categories`;
  try {
    const response = await fetchWithProxy(endpoint);
    const data = await response.json();
    if (Array.isArray(data)) {
      return data;
    }
    return [];
  } catch {
    // If category fetch fails, provide default category
    return [{ category_id: 'all', category_name: 'All Channels' }];
  }
}

/**
 * Fetches Live Streams for a specific category or all categories
 */
export async function getLiveStreams(
  credentials: XtreamCredentials,
  categoryId?: string
): Promise<XtreamLiveStream[]> {
  const server = normalizeServerUrl(credentials.serverUrl);
  if (credentials.username.toLowerCase() === 'demo' || server.includes('demo.streamvibe')) {
    if (!categoryId || categoryId === 'all') {
      return DEMO_STREAMS;
    }
    return DEMO_STREAMS.filter(s => s.category_id === categoryId);
  }

  let endpoint = `${server}/player_api.php?username=${encodeURIComponent(credentials.username)}&password=${encodeURIComponent(credentials.password)}&action=get_live_streams`;
  if (categoryId && categoryId !== 'all') {
    endpoint += `&category_id=${encodeURIComponent(categoryId)}`;
  }

  try {
    const response = await fetchWithProxy(endpoint);
    const data = await response.json();
    if (Array.isArray(data)) {
      return data.map((item, idx) => ({
        ...item,
        num: item.num ?? idx + 1,
        stream_id: Number(item.stream_id),
      }));
    }
    return [];
  } catch (error: any) {
    throw new Error(`Failed to load channels: ${error?.message || 'Server error'}`);
  }
}

/**
 * Generates stream playback URL for live channel
 */
export function buildStreamUrl(
  credentials: XtreamCredentials,
  streamId: number | string,
  streamExtension: 'm3u8' | 'ts' = 'm3u8'
): string {
  const server = normalizeServerUrl(credentials.serverUrl);
  return `${server}/live/${encodeURIComponent(credentials.username)}/${encodeURIComponent(credentials.password)}/${streamId}.${streamExtension}`;
}
