import logoImg from './images/stream_vibe_logo_1791621082009.jpg';

export const STREAM_VIBE_LOGO = logoImg;
export const WHATSAPP_NUMBER = '+923491299788';
export const WHATSAPP_LINK = 'https://wa.me/923491299788?text=Hello%20Stream%20Vibe%20Support%2C%20I%20would%20like%20to%20renew%20my%20IPTV%20subscription.';
