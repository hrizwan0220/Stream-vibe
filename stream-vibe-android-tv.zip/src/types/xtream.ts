export interface XtreamCredentials {
  serverUrl: string;
  username: string;
  password: string;
  serverName?: string;
}

export interface XtreamUserInfo {
  username: string;
  password?: string;
  message?: string;
  auth: number; // 1 = authorized, 0 = unauthorized
  status: 'Active' | 'Banned' | 'Disabled' | 'Expired' | string;
  exp_date?: string; // Unix timestamp string or null
  is_trial?: string;
  active_cons?: string;
  created_at?: string;
  max_connections?: string;
  allowed_output_formats?: string[];
}

export interface XtreamServerInfo {
  url?: string;
  port?: string;
  https_port?: string;
  server_protocol?: string;
  rtmp_port?: string;
  timezone?: string;
  timestamp_now?: number;
  time_now?: string;
}

export interface XtreamAuthResponse {
  user_info: XtreamUserInfo;
  server_info: XtreamServerInfo;
}

export interface XtreamCategory {
  category_id: string;
  category_name: string;
  parent_id?: number;
}

export interface XtreamLiveStream {
  num: number;
  name: string;
  stream_type?: string;
  stream_id: number;
  stream_icon: string;
  epg_channel_id?: string;
  added?: string;
  category_id: string;
  custom_sid?: string;
  tv_archive?: number;
  direct_source?: string;
  // Custom client-side fields
  isFavorite?: boolean;
  categoryName?: string;
  customStreamUrl?: string;
}

export type AspectRatioMode = '16:9' | 'fill' | 'cover' | 'original';

export interface PlayerState {
  isPlaying: boolean;
  isBuffering: boolean;
  isMuted: boolean;
  volume: number;
  aspectRatio: AspectRatioMode;
  error: string | null;
  activeChannel: XtreamLiveStream | null;
  isFullScreen: boolean;
}
