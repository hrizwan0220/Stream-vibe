import React from 'react';
import { 
  ChevronUp, 
  ChevronDown, 
  ChevronLeft, 
  ChevronRight, 
  CornerDownLeft, 
  Home, 
  Maximize2, 
  Minimize2, 
  Volume2, 
  VolumeX, 
  Tv, 
  MessageCircle, 
  HelpCircle,
  X
} from 'lucide-react';
import { WHATSAPP_LINK } from '../assets/logo';
import { tvAudio } from '../utils/tvAudio';

interface TvRemoteControlProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (direction: 'up' | 'down' | 'left' | 'right') => void;
  onSelect: () => void;
  onBack: () => void;
  onHome: () => void;
  isFullScreen: boolean;
  onToggleFullScreen: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
  onNextChannel?: () => void;
  onPrevChannel?: () => void;
  onShowExpiredModal?: () => void;
}

export const TvRemoteControl: React.FC<TvRemoteControlProps> = ({
  isOpen,
  onClose,
  onNavigate,
  onSelect,
  onBack,
  onHome,
  isFullScreen,
  onToggleFullScreen,
  isMuted,
  onToggleMute,
  onNextChannel,
  onPrevChannel,
}) => {
  if (!isOpen) return null;

  const handleDir = (dir: 'up' | 'down' | 'left' | 'right') => {
    tvAudio.playClick();
    onNavigate(dir);
  };

  const handleSelect = () => {
    tvAudio.playSelect();
    onSelect();
  };

  const handleBack = () => {
    tvAudio.playBack();
    onBack();
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 select-none animate-in fade-in slide-in-from-bottom-4 duration-200">
      <div className="relative w-64 bg-slate-950/95 backdrop-blur-xl border border-cyan-500/30 rounded-3xl p-5 shadow-2xl shadow-cyan-950/60 ring-1 ring-purple-500/20 text-white flex flex-col items-center">
        {/* Remote Header */}
        <div className="w-full flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
          <div className="flex items-center space-x-2">
            <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse shadow-sm shadow-cyan-400" />
            <span className="text-xs font-bold tracking-widest text-cyan-400 uppercase">TV Remote</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            title="Minimize Remote"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Top Control Buttons */}
        <div className="grid grid-cols-3 gap-2 w-full mb-4">
          <button
            onClick={() => { tvAudio.playClick(); onHome(); }}
            className="flex flex-col items-center justify-center p-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-cyan-400/50 hover:bg-slate-800 active:scale-95 transition-all group"
            title="Home"
          >
            <Home className="w-4 h-4 text-slate-300 group-hover:text-cyan-400" />
            <span className="text-[9px] text-slate-400 mt-1">HOME</span>
          </button>

          <button
            onClick={() => { tvAudio.playClick(); onToggleMute(); }}
            className="flex flex-col items-center justify-center p-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-purple-400/50 hover:bg-slate-800 active:scale-95 transition-all group"
            title="Mute / Audio"
          >
            {isMuted ? (
              <VolumeX className="w-4 h-4 text-red-400" />
            ) : (
              <Volume2 className="w-4 h-4 text-slate-300 group-hover:text-purple-400" />
            )}
            <span className="text-[9px] text-slate-400 mt-1">{isMuted ? 'MUTED' : 'MUTE'}</span>
          </button>

          <button
            onClick={() => { tvAudio.playClick(); onToggleFullScreen(); }}
            className="flex flex-col items-center justify-center p-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-cyan-400/50 hover:bg-slate-800 active:scale-95 transition-all group"
            title="Full Screen (F)"
          >
            {isFullScreen ? (
              <Minimize2 className="w-4 h-4 text-cyan-400" />
            ) : (
              <Maximize2 className="w-4 h-4 text-slate-300 group-hover:text-cyan-400" />
            )}
            <span className="text-[9px] text-slate-400 mt-1">FULL</span>
          </button>
        </div>

        {/* D-Pad Controller Ring */}
        <div className="relative w-44 h-44 my-2 flex items-center justify-center">
          {/* Outer circle housing */}
          <div className="absolute inset-0 rounded-full bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-800 shadow-inner" />

          {/* D-pad UP */}
          <button
            onClick={() => handleDir('up')}
            className="absolute top-1 left-1/2 -translate-x-1/2 w-16 h-12 flex items-center justify-center text-slate-300 hover:text-cyan-400 active:scale-95 transition-colors focus:outline-none"
            title="D-Pad Up (ArrowUp)"
          >
            <ChevronUp className="w-7 h-7" />
          </button>

          {/* D-pad DOWN */}
          <button
            onClick={() => handleDir('down')}
            className="absolute bottom-1 left-1/2 -translate-x-1/2 w-16 h-12 flex items-center justify-center text-slate-300 hover:text-cyan-400 active:scale-95 transition-colors focus:outline-none"
            title="D-Pad Down (ArrowDown)"
          >
            <ChevronDown className="w-7 h-7" />
          </button>

          {/* D-pad LEFT */}
          <button
            onClick={() => handleDir('left')}
            className="absolute left-1 top-1/2 -translate-y-1/2 w-12 h-16 flex items-center justify-center text-slate-300 hover:text-cyan-400 active:scale-95 transition-colors focus:outline-none"
            title="D-Pad Left (ArrowLeft)"
          >
            <ChevronLeft className="w-7 h-7" />
          </button>

          {/* D-pad RIGHT */}
          <button
            onClick={() => handleDir('right')}
            className="absolute right-1 top-1/2 -translate-y-1/2 w-12 h-16 flex items-center justify-center text-slate-300 hover:text-cyan-400 active:scale-95 transition-colors focus:outline-none"
            title="D-Pad Right (ArrowRight)"
          >
            <ChevronRight className="w-7 h-7" />
          </button>

          {/* Center OK / Select Button */}
          <button
            onClick={handleSelect}
            className="relative z-10 w-16 h-16 rounded-full bg-gradient-to-tr from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 active:scale-90 transition-all flex flex-col items-center justify-center shadow-lg shadow-cyan-500/30 text-white font-extrabold tracking-wider border-2 border-slate-950 text-xs"
            title="Select / OK (Enter)"
          >
            OK
          </button>
        </div>

        {/* Back and Channels row */}
        <div className="grid grid-cols-2 gap-2 w-full mt-4">
          <button
            onClick={handleBack}
            className="flex items-center justify-center space-x-2 py-2.5 px-3 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 hover:bg-slate-850 active:scale-95 transition-all text-xs font-semibold text-slate-200"
            title="Back (Esc / Backspace)"
          >
            <CornerDownLeft className="w-4 h-4 text-purple-400" />
            <span>BACK</span>
          </button>

          <div className="grid grid-cols-2 gap-1">
            <button
              onClick={() => { tvAudio.playClick(); onPrevChannel?.(); }}
              className="flex items-center justify-center py-2 px-1 rounded-xl bg-slate-900 border border-slate-800 hover:border-cyan-500/40 text-[10px] font-bold text-slate-300 active:scale-95 transition-all"
              title="Channel Down"
            >
              CH -
            </button>
            <button
              onClick={() => { tvAudio.playClick(); onNextChannel?.(); }}
              className="flex items-center justify-center py-2 px-1 rounded-xl bg-slate-900 border border-slate-800 hover:border-cyan-500/40 text-[10px] font-bold text-slate-300 active:scale-95 transition-all"
              title="Channel Up"
            >
              CH +
            </button>
          </div>
        </div>

        {/* WhatsApp Renewal Direct Button */}
        <a
          href={WHATSAPP_LINK}
          target="_blank"
          rel="noopener noreferrer"
          className="w-full mt-3 py-2 px-3 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/40 text-emerald-300 text-xs font-medium flex items-center justify-center space-x-2 transition-all hover:scale-[1.02] shadow-sm"
          title="WhatsApp Support / Renewal (+923491299788)"
        >
          <MessageCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
          <span className="truncate">WhatsApp Support</span>
        </a>

        {/* Keyboard hints */}
        <div className="w-full mt-3 pt-2 border-t border-slate-900 flex items-center justify-between text-[9px] text-slate-500">
          <span className="flex items-center gap-1">
            <HelpCircle className="w-3 h-3" /> Keyboard arrows also work
          </span>
          <span className="text-cyan-400/80 font-mono">10-foot TV Mode</span>
        </div>
      </div>
    </div>
  );
};
