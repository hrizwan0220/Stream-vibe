import React, { useEffect, useRef, useState } from 'react';
import Hls from 'hls.js';
import { 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Maximize2, 
  Minimize2, 
  RotateCcw, 
  AlertCircle, 
  Radio, 
  Tv, 
  Sparkles, 
  ChevronLeft, 
  ChevronRight,
  Ratio
} from 'lucide-react';
import { AspectRatioMode, XtreamCredentials, XtreamLiveStream } from '../types/xtream';
import { buildStreamUrl } from '../services/xtreamApi';
import { tvAudio } from '../utils/tvAudio';

interface LivePlayerProps {
  channel: XtreamLiveStream;
  credentials: XtreamCredentials | null;
  onNextChannel: () => void;
  onPrevChannel: () => void;
  onClosePlayer?: () => void;
  isFullScreen: boolean;
  onToggleFullScreen: () => void;
}

export const LivePlayer: React.FC<LivePlayerProps> = ({
  channel,
  credentials,
  onNextChannel,
  onPrevChannel,
  onClosePlayer,
  isFullScreen,
  onToggleFullScreen,
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const hlsRef = useRef<Hls | null>(null);

  const [isPlaying, setIsPlaying] = useState(true);
  const [isBuffering, setIsBuffering] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [aspectRatio, setAspectRatio] = useState<AspectRatioMode>('16:9');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [showOsd, setShowOsd] = useState(true);
  const [streamResolution, setStreamResolution] = useState('1080p 60fps');

  const osdTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Determine stream URL
  const streamUrl = channel.customStreamUrl || (
    credentials ? buildStreamUrl(credentials, channel.stream_id, 'm3u8') : ''
  );

  const resetOsdTimer = () => {
    setShowOsd(true);
    if (osdTimerRef.current) clearTimeout(osdTimerRef.current);
    osdTimerRef.current = setTimeout(() => {
      setShowOsd(false);
    }, 4500);
  };

  useEffect(() => {
    resetOsdTimer();
    return () => {
      if (osdTimerRef.current) clearTimeout(osdTimerRef.current);
    };
  }, [channel]);

  // Load and play stream
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !streamUrl) return;

    setErrorMessage(null);
    setIsBuffering(true);

    // Destroy existing HLS instance
    if (hlsRef.current) {
      hlsRef.current.destroy();
      hlsRef.current = null;
    }

    // Check if HLS.js is supported
    if (Hls.isSupported() && streamUrl.includes('.m3u8')) {
      const hls = new Hls({
        enableWorker: true,
        lowLatencyMode: true,
        backBufferLength: 90,
      });
      hlsRef.current = hls;

      hls.loadSource(streamUrl);
      hls.attachMedia(video);

      hls.on(Hls.Events.MANIFEST_PARSED, (_, data) => {
        setIsBuffering(false);
        video.play().catch(() => {
          // Autoplay policy might mute or require interaction
          video.muted = true;
          setIsMuted(true);
          video.play().catch(() => {});
        });
        if (data.levels && data.levels.length > 0) {
          const highest = data.levels[data.levels.length - 1];
          if (highest.height) {
            setStreamResolution(`${highest.height}p ${highest.frameRate ? Math.round(highest.frameRate) + 'fps' : 'HD'}`);
          }
        }
      });

      hls.on(Hls.Events.ERROR, (_, data) => {
        if (data.fatal) {
          switch (data.type) {
            case Hls.ErrorTypes.NETWORK_ERROR:
              // Try to recover network error
              hls.startLoad();
              break;
            case Hls.ErrorTypes.MEDIA_ERROR:
              hls.recoverMediaError();
              break;
            default:
              setErrorMessage('Live stream could not be loaded. Channel may be offline or restricted by provider.');
              setIsBuffering(false);
              hls.destroy();
              break;
          }
        }
      });
    } else {
      // Fallback to native HTML5 video (e.g. Safari or standard MP4/HLS)
      video.src = streamUrl;
      video.play().then(() => {
        setIsBuffering(false);
      }).catch(() => {
        video.muted = true;
        setIsMuted(true);
        video.play().catch(() => {
          setErrorMessage('Unable to play stream format directly. The provider stream may require native ExoPlayer.');
          setIsBuffering(false);
        });
      });
    }

    return () => {
      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
    };
  }, [streamUrl]);

  const togglePlay = () => {
    tvAudio.playClick();
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      videoRef.current.play();
      setIsPlaying(true);
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
    }
    resetOsdTimer();
  };

  const toggleMute = () => {
    tvAudio.playClick();
    if (!videoRef.current) return;
    videoRef.current.muted = !videoRef.current.muted;
    setIsMuted(videoRef.current.muted);
    resetOsdTimer();
  };

  const cycleAspectRatio = () => {
    tvAudio.playClick();
    const modes: AspectRatioMode[] = ['16:9', 'fill', 'cover'];
    const nextIdx = (modes.indexOf(aspectRatio) + 1) % modes.length;
    setAspectRatio(modes[nextIdx]);
    resetOsdTimer();
  };

  const handleRetry = () => {
    tvAudio.playClick();
    setErrorMessage(null);
    setIsBuffering(true);
    if (videoRef.current) {
      videoRef.current.load();
      videoRef.current.play().catch(() => {});
    }
  };

  // Video object-fit style
  const videoObjectFit = aspectRatio === 'fill' ? 'fill' : aspectRatio === 'cover' ? 'cover' : 'contain';

  return (
    <div
      onMouseMove={resetOsdTimer}
      onClick={resetOsdTimer}
      className={`relative w-full h-full bg-black overflow-hidden select-none flex items-center justify-center ${
        isFullScreen ? 'fixed inset-0 z-50' : 'rounded-2xl'
      }`}
    >
      {/* HTML5 / HLS Video Element */}
      <video
        ref={videoRef}
        playsInline
        autoPlay
        onWaiting={() => setIsBuffering(true)}
        onPlaying={() => { setIsBuffering(false); setIsPlaying(true); }}
        onError={() => {
          setIsBuffering(false);
          setErrorMessage('Stream unavailable: Provider server offline or stream disconnected.');
        }}
        className="w-full h-full transition-all"
        style={{ objectFit: videoObjectFit }}
      />

      {/* Buffering Spinner */}
      {isBuffering && !errorMessage && (
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none bg-black/40 backdrop-blur-[2px]">
          <div className="relative w-16 h-16 flex items-center justify-center">
            <div className="w-16 h-16 rounded-full border-4 border-slate-700 border-t-cyan-400 border-r-purple-500 animate-spin" />
            <Radio className="w-6 h-6 text-cyan-400 absolute" />
          </div>
          <span className="mt-3 text-xs font-bold text-cyan-300 uppercase tracking-widest animate-pulse">
            Buffering Stream...
          </span>
        </div>
      )}

      {/* Error Overlay */}
      {errorMessage && (
        <div className="absolute inset-0 z-30 bg-slate-950/90 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center animate-in fade-in">
          <div className="w-16 h-16 rounded-2xl bg-red-950/60 border border-red-500/50 flex items-center justify-center mb-4 text-red-400">
            <AlertCircle className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-extrabold text-white mb-2">Stream Playback Failed</h3>
          <p className="text-sm text-slate-300 max-w-md mb-6">{errorMessage}</p>

          <div className="flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={handleRetry}
              className="py-2.5 px-5 rounded-xl bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-slate-950 font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg transition-transform active:scale-95"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Retry Stream</span>
            </button>
            <button
              onClick={() => { tvAudio.playClick(); onNextChannel(); }}
              className="py-2.5 px-5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs flex items-center gap-2 transition-transform active:scale-95"
            >
              <span>Next Channel</span>
              <ChevronRight className="w-4 h-4 text-cyan-400" />
            </button>
          </div>
        </div>
      )}

      {/* Media3 ExoPlayer Styled On-Screen Display (OSD) Overlay */}
      <div
        className={`absolute inset-0 z-20 flex flex-col justify-between p-4 md:p-8 bg-gradient-to-t from-black/90 via-transparent to-black/80 transition-opacity duration-300 pointer-events-none ${
          showOsd ? 'opacity-100' : 'opacity-0'
        }`}
      >
        {/* Top OSD Header */}
        <div className="flex items-center justify-between pointer-events-auto">
          {/* Channel info banner */}
          <div className="flex items-center space-x-4 bg-slate-950/80 backdrop-blur-md border border-slate-800/80 px-4 py-2.5 rounded-2xl shadow-xl">
            {channel.stream_icon ? (
              <img
                src={channel.stream_icon}
                alt={channel.name}
                className="w-10 h-10 rounded-xl object-cover bg-slate-900 border border-slate-700"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
            ) : (
              <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-700 flex items-center justify-center text-cyan-400 font-bold">
                <Tv className="w-5 h-5" />
              </div>
            )}

            <div>
              <div className="flex items-center space-x-2">
                <span className="font-mono text-xs font-black text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-500/30">
                  CH {channel.num || channel.stream_id}
                </span>
                <h2 className="text-base font-extrabold text-white tracking-wide truncate max-w-xs md:max-w-md">
                  {channel.name}
                </h2>
              </div>
              <div className="flex items-center space-x-2 text-[11px] text-slate-400 mt-0.5">
                <span>{channel.categoryName || 'Live TV'}</span>
                <span>•</span>
                <span className="text-purple-300">ExoPlayer Engine</span>
              </div>
            </div>
          </div>

          {/* Stream Quality Badges */}
          <div className="flex items-center space-x-2">
            <div className="flex items-center space-x-1.5 bg-red-600/30 border border-red-500/40 px-3 py-1.5 rounded-xl shadow-md backdrop-blur-md">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
              <span className="text-[11px] font-black text-red-200 uppercase tracking-widest">LIVE</span>
            </div>

            <div className="hidden sm:flex items-center space-x-1.5 bg-cyan-950/60 border border-cyan-500/40 px-3 py-1.5 rounded-xl text-cyan-300 text-xs font-mono font-bold shadow-md backdrop-blur-md">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>{streamResolution}</span>
            </div>

            {onClosePlayer && (
              <button
                onClick={() => { tvAudio.playBack(); onClosePlayer(); }}
                className="pointer-events-auto p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700 transition-colors"
                title="Return to Guide (Esc)"
              >
                ✕
              </button>
            )}
          </div>
        </div>

        {/* Center Quick Channel Zapping Arrows */}
        <div className="flex items-center justify-between w-full pointer-events-auto px-2">
          <button
            onClick={() => { tvAudio.playClick(); onPrevChannel(); }}
            className="p-3 rounded-full bg-slate-900/60 hover:bg-cyan-500/20 text-white/70 hover:text-cyan-300 border border-slate-700/50 hover:border-cyan-400/50 backdrop-blur-md transition-all active:scale-95"
            title="Previous Channel (CH-)"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          <button
            onClick={() => { tvAudio.playClick(); onNextChannel(); }}
            className="p-3 rounded-full bg-slate-900/60 hover:bg-cyan-500/20 text-white/70 hover:text-cyan-300 border border-slate-700/50 hover:border-cyan-400/50 backdrop-blur-md transition-all active:scale-95"
            title="Next Channel (CH+)"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>

        {/* Bottom OSD Bar Controls */}
        <div className="flex items-center justify-between bg-slate-950/85 backdrop-blur-xl border border-slate-800/80 px-5 py-3 rounded-2xl pointer-events-auto shadow-2xl">
          <div className="flex items-center space-x-3">
            {/* Play / Pause */}
            <button
              onClick={togglePlay}
              className="p-2.5 rounded-xl bg-gradient-to-tr from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-slate-950 font-bold transition-transform active:scale-90"
              title="Play / Pause (Space)"
            >
              {isPlaying ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current ml-0.5" />}
            </button>

            {/* Mute */}
            <button
              onClick={toggleMute}
              className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 hover:text-white border border-slate-800 transition-colors"
              title="Mute / Unmute (M)"
            >
              {isMuted ? <VolumeX className="w-5 h-5 text-red-400" /> : <Volume2 className="w-5 h-5 text-cyan-400" />}
            </button>

            {/* Aspect Ratio */}
            <button
              onClick={cycleAspectRatio}
              className="hidden sm:flex items-center space-x-1.5 px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 text-xs font-semibold"
              title="Cycle Aspect Ratio"
            >
              <Ratio className="w-4 h-4 text-purple-400" />
              <span className="uppercase">{aspectRatio}</span>
            </button>
          </div>

          {/* Fullscreen & Status */}
          <div className="flex items-center space-x-3">
            <span className="hidden md:inline text-xs text-slate-400 font-mono">
              Use D-pad arrows to zap channels • OK for info
            </span>

            <button
              onClick={() => { tvAudio.playClick(); onToggleFullScreen(); }}
              className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 hover:text-cyan-400 border border-slate-800 transition-colors"
              title="Toggle Fullscreen (F)"
            >
              {isFullScreen ? <Minimize2 className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
