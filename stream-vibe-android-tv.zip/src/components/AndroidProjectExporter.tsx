import React, { useState } from 'react';
import { 
  Download, 
  FileCode, 
  Check, 
  Copy, 
  Terminal, 
  Tv, 
  Cpu, 
  Layers, 
  ShieldCheck, 
  Sparkles, 
  X,
  ExternalLink,
  Smartphone,
  FolderGit2,
  MessageCircle
} from 'lucide-react';
import { STREAM_VIBE_LOGO, WHATSAPP_LINK, WHATSAPP_NUMBER } from '../assets/logo';
import { tvAudio } from '../utils/tvAudio';

interface AndroidProjectExporterProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidProjectExporter: React.FC<AndroidProjectExporterProps> = ({
  isOpen,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'guide' | 'code' | 'specs'>('guide');
  const [selectedFileKey, setSelectedFileKey] = useState<string>('MainActivity.kt');
  const [copiedCode, setCopiedCode] = useState(false);

  if (!isOpen) return null;

  // Code repository data map
  const projectFiles: Record<string, { path: string; language: string; content: string }> = {
    'MainActivity.kt': {
      path: 'app/src/main/java/com/streamvibe/tv/MainActivity.kt',
      language: 'kotlin',
      content: `package com.streamvibe.tv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import com.streamvibe.tv.data.model.LiveCategory
import com.streamvibe.tv.data.model.LiveStream
import com.streamvibe.tv.data.model.UserCredentials
import com.streamvibe.tv.data.repository.XtreamRepository
import com.streamvibe.tv.data.storage.SecureCredentialsManager
import com.streamvibe.tv.ui.screens.*
import com.streamvibe.tv.ui.theme.StreamVibeTheme
import kotlinx.coroutines.launch

sealed class Screen {
    object Splash : Screen()
    object Login : Screen()
    object Main : Screen()
    data class Player(val channel: LiveStream) : Screen()
    data class Expired(val username: String) : Screen()
}

class MainActivity : ComponentActivity() {

    private val repository = XtreamRepository()
    private lateinit var credentialsManager: SecureCredentialsManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        credentialsManager = SecureCredentialsManager(this)

        setContent {
            StreamVibeTheme {
                val coroutineScope = rememberCoroutineScope()
                var currentScreen by remember { mutableStateOf<Screen>(Screen.Splash) }
                var activeCredentials by remember { mutableStateOf<UserCredentials?>(null) }
                var categories by remember { mutableStateOf<List<LiveCategory>>(emptyList()) }
                var channels by remember { mutableStateOf<List<LiveStream>>(emptyList()) }
                var selectedCategoryId by remember { mutableStateOf<String?>("all") }
                var isLoading by remember { mutableStateOf(false) }
                var errorMessage by remember { mutableStateOf<String?>(null) }

                fun performLogin(credentials: UserCredentials) {
                    isLoading = true
                    errorMessage = null
                    coroutineScope.launch {
                        val authResult = repository.authenticate(credentials)
                        authResult.onSuccess { response ->
                            val user = response.userInfo
                            if (user?.status?.equals("Expired", ignoreCase = true) == true) {
                                isLoading = false
                                currentScreen = Screen.Expired(credentials.username)
                                return@launch
                            }

                            credentialsManager.saveCredentials(credentials)
                            activeCredentials = credentials

                            val catResult = repository.getCategories(credentials)
                            categories = catResult.getOrDefault(listOf(LiveCategory("all", "All Channels")))

                            val streamResult = repository.getStreams(credentials)
                            channels = streamResult.getOrDefault(emptyList())

                            isLoading = false
                            currentScreen = Screen.Main
                        }.onFailure { error ->
                            isLoading = false
                            errorMessage = error.localizedMessage ?: "Login failed. Check server and credentials."
                        }
                    }
                }

                when (val screen = currentScreen) {
                    is Screen.Splash -> {
                        SplashScreen(
                            onNavigateNext = {
                                val saved = credentialsManager.getCredentials()
                                if (saved != null) {
                                    performLogin(saved)
                                } else {
                                    currentScreen = Screen.Login
                                }
                            }
                        )
                    }

                    is Screen.Login -> {
                        LoginScreen(
                            onLoginSubmit = { creds -> performLogin(creds) },
                            isLoading = isLoading,
                            errorMessage = errorMessage
                        )
                    }

                    is Screen.Main -> {
                        MainTvScreen(
                            categories = categories,
                            channels = channels,
                            selectedCategoryId = selectedCategoryId,
                            onSelectCategory = { catId ->
                                selectedCategoryId = catId
                                coroutineScope.launch {
                                    activeCredentials?.let { creds ->
                                        val filterId = if (catId == "all") null else catId
                                        val res = repository.getStreams(creds, filterId)
                                        channels = res.getOrDefault(emptyList())
                                    }
                                }
                            },
                            onSelectChannel = { channel ->
                                currentScreen = Screen.Player(channel)
                            },
                            onLogout = {
                                credentialsManager.clearCredentials()
                                activeCredentials = null
                                currentScreen = Screen.Login
                            }
                        )
                    }

                    is Screen.Player -> {
                        activeCredentials?.let { creds ->
                            PlayerScreen(
                                channel = screen.channel,
                                credentials = creds,
                                onBackToGuide = { currentScreen = Screen.Main }
                            )
                        } ?: run {
                            currentScreen = Screen.Login
                        }
                    }

                    is Screen.Expired -> {
                        SubscriptionExpiredScreen(
                            username = screen.username,
                            onRelogin = {
                                credentialsManager.clearCredentials()
                                currentScreen = Screen.Login
                            }
                        )
                    }
                }
            }
        }
    }
}`,
    },
    'Media3PlayerManager.kt': {
      path: 'app/src/main/java/com/streamvibe/tv/player/Media3PlayerManager.kt',
      language: 'kotlin',
      content: `package com.streamvibe.tv.player

import android.content.Context
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

sealed class PlayerState {
    object Idle : PlayerState()
    object Buffering : PlayerState()
    object Ready : PlayerState()
    object Ended : PlayerState()
    data class Error(val message: String) : PlayerState()
}

@OptIn(UnstableApi::class)
class Media3PlayerManager(private val context: Context) {

    private var exoPlayer: ExoPlayer? = null
    private val _playbackState = MutableStateFlow<PlayerState>(PlayerState.Idle)
    val playbackState: StateFlow<PlayerState> = _playbackState

    fun initializePlayer(): ExoPlayer {
        if (exoPlayer == null) {
            val loadControl = DefaultLoadControl.Builder()
                .setBufferDurationsMs(2000, 8000, 1000, 1500)
                .build()

            exoPlayer = ExoPlayer.Builder(context)
                .setLoadControl(loadControl)
                .setWakeMode(C.WAKE_MODE_NETWORK)
                .build()
                .apply {
                    playWhenReady = true
                    addListener(object : Player.Listener {
                        override fun onPlaybackStateChanged(state: Int) {
                            when (state) {
                                Player.STATE_IDLE -> _playbackState.value = PlayerState.Idle
                                Player.STATE_BUFFERING -> _playbackState.value = PlayerState.Buffering
                                Player.STATE_READY -> _playbackState.value = PlayerState.Ready
                                Player.STATE_ENDED -> _playbackState.value = PlayerState.Ended
                            }
                        }

                        override fun onPlayerError(error: PlaybackException) {
                            _playbackState.value = PlayerState.Error(
                                error.localizedMessage ?: "Stream playback failed."
                            )
                        }
                    })
                }
        }
        return exoPlayer!!
    }

    fun playStream(streamUrl: String) {
        val player = initializePlayer()
        val uri = Uri.parse(streamUrl)

        val dataSourceFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("IPTVSmartersPro/3.1.5.1 (Linux; Android 12; StreamVibeTV)")
            .setConnectTimeoutMs(12000)
            .setReadTimeoutMs(20000)
            .setAllowCrossProtocolRedirects(true)

        val mediaSource: MediaSource = if (streamUrl.contains(".m3u8")) {
            HlsMediaSource.Factory(dataSourceFactory)
                .setAllowChunklessPreparation(true)
                .createMediaSource(MediaItem.fromUri(uri))
        } else {
            ProgressiveMediaSource.Factory(dataSourceFactory)
                .createMediaSource(MediaItem.fromUri(uri))
        }

        player.setMediaSource(mediaSource)
        player.prepare()
        player.play()
    }

    fun release() {
        exoPlayer?.release()
        exoPlayer = null
        _playbackState.value = PlayerState.Idle
    }
}`,
    },
    'SecureCredentialsManager.kt': {
      path: 'app/src/main/java/com/streamvibe/tv/data/storage/SecureCredentialsManager.kt',
      language: 'kotlin',
      content: `package com.streamvibe.tv.data.storage

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.streamvibe.tv.data.model.UserCredentials

/**
 * Secure credential storage using Android EncryptedSharedPreferences.
 * NEVER hardcodes credentials in the APK.
 */
class SecureCredentialsManager(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val sharedPreferences = try {
        EncryptedSharedPreferences.create(
            context,
            "stream_vibe_secure_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        context.getSharedPreferences("stream_vibe_fallback_prefs", Context.MODE_PRIVATE)
    }

    companion object {
        private const val KEY_SERVER_URL = "xtream_server_url"
        private const val KEY_USERNAME = "xtream_username"
        private const val KEY_PASSWORD = "xtream_password"
    }

    fun saveCredentials(credentials: UserCredentials) {
        sharedPreferences.edit()
            .putString(KEY_SERVER_URL, credentials.serverUrl.trim())
            .putString(KEY_USERNAME, credentials.username.trim())
            .putString(KEY_PASSWORD, credentials.password.trim())
            .apply()
    }

    fun getCredentials(): UserCredentials? {
        val server = sharedPreferences.getString(KEY_SERVER_URL, null)
        val user = sharedPreferences.getString(KEY_USERNAME, null)
        val pass = sharedPreferences.getString(KEY_PASSWORD, null)

        if (!server.isNullOrBlank() && !user.isNullOrBlank() && !pass.isNullOrBlank()) {
            return UserCredentials(server, user, pass)
        }
        return null
    }

    fun clearCredentials() {
        sharedPreferences.edit()
            .remove(KEY_SERVER_URL)
            .remove(KEY_USERNAME)
            .remove(KEY_PASSWORD)
            .apply()
    }
}`,
    },
    'SubscriptionExpiredScreen.kt': {
      path: 'app/src/main/java/com/streamvibe/tv/ui/screens/SubscriptionExpiredScreen.kt',
      language: 'kotlin',
      content: `package com.streamvibe.tv.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.streamvibe.tv.ui.theme.*

@Composable
fun SubscriptionExpiredScreen(
    username: String,
    onRelogin: () -> Unit
) {
    val context = LocalContext.current
    val whatsappNumber = "+923491299788"
    val renewalUrl = "https://wa.me/923491299788?text=" + Uri.encode(
        "Hello Stream Vibe Support, I would like to renew my IPTV subscription for account: $username"
    )

    fun openWhatsApp(ctx: Context) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(renewalUrl)).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        ctx.startActivity(intent)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NavyBackground),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .width(580.dp)
                .clip(RoundedCornerShape(24.dp))
                .border(1.dp, PurpleAccent.copy(alpha = 0.4f), RoundedCornerShape(24.dp)),
            colors = CardDefaults.cardColors(containerColor = NavyCard)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(AlertRed.copy(alpha = 0.15f))
                        .border(1.dp, AlertRed.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "SUBSCRIPTION EXPIRED",
                        color = AlertRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "Renew Your Stream Vibe Access",
                    color = Color.White,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Customer Account: $username\\nYour subscription has ended. Contact our official WhatsApp customer support to renew your plan instantly and restore all live channels.",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(28.dp))

                Button(
                    onClick = { openWhatsApp(context) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = WhatsAppGreen)
                ) {
                    Text(
                        text = "Renew on WhatsApp ($whatsappNumber)",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedButton(
                    onClick = onRelogin,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(
                        text = "Switch Account / Re-login",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}`,
    },
    'AndroidManifest.xml': {
      path: 'app/src/main/AndroidManifest.xml',
      language: 'xml',
      content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />

    <uses-feature android:name="android.software.leanback" android:required="false" />
    <uses-feature android:name="android.hardware.touchscreen" android:required="false" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:banner="@drawable/banner"
        android:supportsRtl="true"
        android:usesCleartextTraffic="true"
        android:theme="@style/Theme.StreamVibe">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:screenOrientation="landscape"
            android:theme="@style/Theme.StreamVibe">

            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>

            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LEANBACK_LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`,
    },
    'app/build.gradle.kts': {
      path: 'app/build.gradle.kts',
      language: 'gradle',
      content: `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.streamvibe.tv"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.streamvibe.tv"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}

dependencies {
    implementation("androidx.tv:tv-foundation:1.0.0-alpha11")
    implementation("androidx.tv:tv-material:1.0.0-alpha11")
    implementation("androidx.media3:media3-exoplayer:1.3.1")
    implementation("androidx.media3:media3-ui:1.3.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.3.1")
    implementation("com.squareup.retrofit2:retrofit:2.11.0")
    implementation("com.squareup.retrofit2:converter-gson:2.11.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("io.coil-kt:coil-compose:2.6.0")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
}`,
    },
  };

  const handleDownloadZip = () => {
    tvAudio.playSelect();
    const link = document.createElement('a');
    link.href = '/stream-vibe-android-tv.zip';
    link.setAttribute('download', 'stream-vibe-android-tv.zip');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleCopyCurrentCode = () => {
    tvAudio.playClick();
    const content = projectFiles[selectedFileKey]?.content || '';
    navigator.clipboard.writeText(content);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-xl p-4 md:p-8 select-none">
      <div className="relative w-full max-w-5xl h-[88vh] bg-slate-950 border border-cyan-500/30 rounded-3xl flex flex-col overflow-hidden shadow-2xl shadow-cyan-950/80 ring-1 ring-purple-500/20 text-white animate-in zoom-in-95 duration-200">
        {/* Top Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between shrink-0 bg-slate-900/60">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl overflow-hidden border border-cyan-400/50 shadow-md">
              <img src={STREAM_VIBE_LOGO} alt="Stream Vibe" className="w-full h-full object-cover" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-base font-extrabold uppercase tracking-tight text-white">
                  Stream <span className="text-cyan-400">Vibe</span> Android Studio Project
                </h2>
                <span className="text-[10px] font-mono bg-purple-950/80 border border-purple-500/40 text-purple-300 px-2 py-0.5 rounded-full">
                  Kotlin + Compose TV
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Complete buildable native Android TV app codebase with Media3 ExoPlayer
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <a
              href="/stream-vibe-android-tv.zip"
              download="stream-vibe-android-tv.zip"
              onClick={() => tvAudio.playSelect()}
              className="py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-400 to-purple-600 hover:from-cyan-300 hover:to-purple-500 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg shadow-cyan-500/25 flex items-center space-x-2 transition-all active:scale-95"
            >
              <Download className="w-4 h-4" />
              <span>Download Project ZIP</span>
            </a>

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="px-6 pt-3 border-b border-slate-800 flex items-center space-x-4 shrink-0 bg-slate-900/30">
          <button
            onClick={() => { tvAudio.playClick(); setActiveTab('guide'); }}
            className={`pb-3 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 border-b-2 transition-all ${
              activeTab === 'guide'
                ? 'border-cyan-400 text-cyan-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Terminal className="w-4 h-4" />
            <span>How to Obtain Installable APK</span>
          </button>

          <button
            onClick={() => { tvAudio.playClick(); setActiveTab('code'); }}
            className={`pb-3 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 border-b-2 transition-all ${
              activeTab === 'code'
                ? 'border-cyan-400 text-cyan-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileCode className="w-4 h-4" />
            <span>Interactive Code Inspector</span>
          </button>

          <button
            onClick={() => { tvAudio.playClick(); setActiveTab('specs'); }}
            className={`pb-3 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 border-b-2 transition-all ${
              activeTab === 'specs'
                ? 'border-cyan-400 text-cyan-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Cpu className="w-4 h-4" />
            <span>Architecture & Security Specs</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="flex-1 overflow-y-auto p-6 custom-scrollbar">
          {activeTab === 'guide' && (
            <div className="space-y-6 max-w-4xl">
              {/* Phone-Only Highlight Banner */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-cyan-950/70 to-purple-950/70 border border-cyan-500/40 flex items-start space-x-3 shadow-lg">
                <Smartphone className="w-6 h-6 text-cyan-400 shrink-0 mt-0.5" />
                <div className="text-xs text-slate-300 space-y-1.5 flex-1">
                  <div className="flex items-center justify-between">
                    <p className="font-extrabold text-white text-sm">
                      📱 Phone-Only Guide: No PC Required!
                    </p>
                    <a
                      href="/stream-vibe-android-tv.zip"
                      download="stream-vibe-android-tv.zip"
                      className="px-3 py-1 rounded-lg bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-[11px] flex items-center gap-1 transition-colors"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download ZIP (600 KB)</span>
                    </a>
                  </div>
                  <p>
                    You can obtain a real, installable Android APK right from your smartphone using GitHub's free cloud builder or using the AndroidIDE app directly on your phone.
                  </p>
                </div>
              </div>

              {/* Step 1: Phone-Only GitHub Actions Cloud Builder */}
              <div className="bg-slate-900/60 border border-cyan-500/30 rounded-2xl p-5">
                <div className="flex items-center space-x-2 text-cyan-400 font-bold text-sm mb-3">
                  <span className="w-6 h-6 rounded-full bg-cyan-950 border border-cyan-500/50 flex items-center justify-center text-xs">1</span>
                  <span>Method 1 (Fastest on Phone): GitHub Actions Free Cloud Builder</span>
                </div>
                <div className="text-xs text-slate-300 space-y-2 pl-8">
                  <p>1. Tap <strong className="text-cyan-300">Download Project ZIP</strong> above to save <code className="text-purple-300">stream-vibe-android-tv.zip</code> onto your phone.</p>
                  <p>2. Open your phone's browser (Chrome/Firefox) and go to <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="text-cyan-400 underline">github.com</a>.</p>
                  <p>3. Tap <strong>+ &gt; New Repository</strong>, name it <code className="text-purple-300">stream-vibe-tv</code>, and tap Create.</p>
                  <p>4. Extract the ZIP on your phone, tap <strong>Upload files</strong> in GitHub, upload the files, and commit.</p>
                  <p>5. Tap the <strong>Actions</strong> tab &gt; <strong>Build Stream Vibe Android TV APK</strong> &gt; tap <strong>Run workflow</strong>.</p>
                  <p>6. In ~2 minutes, the cloud build completes with a green checkmark. Tap the build and download <strong className="text-emerald-400">StreamVibe-AndroidTV-APK</strong> directly onto your phone!</p>
                </div>
              </div>

              {/* Step 2: AndroidIDE Native Compiler on Phone */}
              <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-5">
                <div className="flex items-center space-x-2 text-purple-400 font-bold text-sm mb-3">
                  <span className="w-6 h-6 rounded-full bg-purple-950 border border-purple-500/40 flex items-center justify-center text-xs">2</span>
                  <span>Method 2: Compile Locally on Phone using AndroidIDE</span>
                </div>
                <div className="text-xs text-slate-300 space-y-2 pl-8">
                  <p>1. Install the free <strong>AndroidIDE</strong> app from <a href="https://androidide.com" target="_blank" rel="noopener noreferrer" className="text-purple-400 underline">androidide.com</a> or F-Droid.</p>
                  <p>2. Extract <code className="text-cyan-300">stream-vibe-android-tv.zip</code> into your phone's internal storage.</p>
                  <p>3. Open AndroidIDE, tap <strong>Open Project</strong>, and select the unzipped StreamVibe directory.</p>
                  <p>4. In the built-in terminal, run <code className="text-cyan-300 font-mono">./gradlew assembleDebug</code>.</p>
                  <p>5. Your APK will be compiled directly on your phone in <code className="text-purple-300 font-mono">app/build/outputs/apk/debug/app-debug.apk</code>.</p>
                </div>
              </div>

              {/* Step 3: Installing onto Android TV / Fire Stick */}
              <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-5">
                <div className="flex items-center space-x-2 text-emerald-400 font-bold text-sm mb-3">
                  <span className="w-6 h-6 rounded-full bg-emerald-950 border border-emerald-500/40 flex items-center justify-center text-xs">3</span>
                  <span>How to Install the APK on Your Android TV / Fire TV Stick</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pl-8 text-xs text-slate-300">
                  <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
                    <span className="font-bold text-white block mb-1">Option 1: ADB Wireless</span>
                    <p className="text-[11px] text-slate-400 mb-2">Enable Developer Options on TV, then run:</p>
                    <code className="text-[10px] text-cyan-300 font-mono block bg-slate-900 p-1.5 rounded">
                      adb connect 192.168.1.50:5555<br/>
                      adb install -r app-debug.apk
                    </code>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
                    <span className="font-bold text-white block mb-1">Option 2: TV "Downloader" App</span>
                    <p className="text-[11px] text-slate-400">
                      Install the free <strong>Downloader</strong> app from the Google Play Store or Amazon Appstore, enter your direct APK link, and click Download &amp; Install.
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
                    <span className="font-bold text-white block mb-1">Option 3: USB Flash Drive</span>
                    <p className="text-[11px] text-slate-400">
                      Copy the generated <code className="text-purple-300 font-mono">.apk</code> to a USB stick, insert it into your Android TV box, open any File Manager, and tap Install.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'code' && (
            <div className="flex flex-col md:flex-row h-full gap-4">
              {/* File List */}
              <div className="w-full md:w-64 shrink-0 space-y-1">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2 block">
                  Project Files ({Object.keys(projectFiles).length})
                </span>
                {Object.keys(projectFiles).map((fileKey) => (
                  <button
                    key={fileKey}
                    onClick={() => { tvAudio.playClick(); setSelectedFileKey(fileKey); }}
                    className={`w-full text-left px-3 py-2 rounded-xl text-xs font-mono flex items-center justify-between transition-all ${
                      selectedFileKey === fileKey
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold'
                        : 'text-slate-400 hover:bg-slate-900 hover:text-white'
                    }`}
                  >
                    <span className="truncate">{fileKey}</span>
                  </button>
                ))}
              </div>

              {/* Code Viewer */}
              <div className="flex-1 flex flex-col bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden min-h-[400px]">
                <div className="px-4 py-2.5 bg-slate-900/80 border-b border-slate-800 flex items-center justify-between text-xs">
                  <span className="font-mono text-slate-400">
                    {projectFiles[selectedFileKey]?.path}
                  </span>
                  <button
                    onClick={handleCopyCurrentCode}
                    className="flex items-center space-x-1.5 py-1 px-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs transition-colors"
                  >
                    {copiedCode ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy Code</span>
                      </>
                    )}
                  </button>
                </div>
                <div className="flex-1 p-4 overflow-auto custom-scrollbar font-mono text-[11px] text-slate-300 leading-relaxed">
                  <pre>{projectFiles[selectedFileKey]?.content}</pre>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'specs' && (
            <div className="space-y-6 max-w-4xl text-xs text-slate-300">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-2">
                  <div className="flex items-center space-x-2 text-cyan-400 font-bold text-sm">
                    <ShieldCheck className="w-4 h-4" />
                    <span>Never Hardcoded Credentials Security</span>
                  </div>
                  <p>
                    In accordance with strict security standards, Stream Vibe never embeds shared credentials in the APK. Each customer logs in dynamically at runtime.
                  </p>
                  <p className="text-slate-400 text-[11px]">
                    Credentials are saved in hardware-backed <code className="text-purple-300">EncryptedSharedPreferences</code> using AES-256 GCM encryption on the customer device.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-2">
                  <div className="flex items-center space-x-2 text-purple-400 font-bold text-sm">
                    <Tv className="w-4 h-4" />
                    <span>Android Media3 ExoPlayer Engine</span>
                  </div>
                  <p>
                    Uses official <code className="text-cyan-300">androidx.media3.exoplayer</code> with native HLS chunkless preparation, low latency buffers, and network state recovery.
                  </p>
                  <p className="text-slate-400 text-[11px]">
                    Handles TS streams, M3U8 multi-bitrate playlists, and audio track switching automatically.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-2">
                  <div className="flex items-center space-x-2 text-emerald-400 font-bold text-sm">
                    <MessageCircle className="w-4 h-4" />
                    <span>WhatsApp Renewal Service</span>
                  </div>
                  <p>
                    When an account is flagged as expired, Stream Vibe displays the subscription-expired screen with direct Intent to WhatsApp:
                  </p>
                  <a
                    href={WHATSAPP_LINK}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-block p-2 rounded-xl bg-emerald-950/50 border border-emerald-500/40 text-emerald-300 font-mono text-[11px] hover:underline"
                  >
                    https://wa.me/923491299788
                  </a>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-2">
                  <div className="flex items-center space-x-2 text-cyan-400 font-bold text-sm">
                    <Layers className="w-4 h-4" />
                    <span>D-Pad Leanback Navigation</span>
                  </div>
                  <p>
                    Optimized for physical TV remote controllers (Fire TV, Android TV, Google TV, NVIDIA Shield). Every card and rail responds to standard D-pad DPAD_UP, DPAD_DOWN, DPAD_LEFT, DPAD_RIGHT, and DPAD_CENTER.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
