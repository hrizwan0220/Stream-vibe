import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Star, 
  Tv, 
  Radio, 
  Play, 
  Heart, 
  Sparkles, 
  MessageCircle, 
  Layers, 
  Filter, 
  Download,
  AlertCircle,
  Clock,
  User,
  LogOut,
  Maximize2
} from 'lucide-react';
import { XtreamCategory, XtreamCredentials, XtreamLiveStream, XtreamUserInfo } from '../types/xtream';
import { STREAM_VIBE_LOGO, WHATSAPP_LINK, WHATSAPP_NUMBER } from '../assets/logo';
import { tvAudio } from '../utils/tvAudio';

interface ChannelGuideProps {
  categories: XtreamCategory[];
  channels: XtreamLiveStream[];
  activeCategoryId: string;
  onSelectCategory: (categoryId: string) => void;
  activeChannel: XtreamLiveStream | null;
  onSelectChannel: (channel: XtreamLiveStream) => void;
  onOpenPlayer: (channel: XtreamLiveStream) => void;
  userInfo: XtreamUserInfo | null;
  credentials: XtreamCredentials | null;
  onLogout: () => void;
  onOpenAndroidExport: () => void;
  onTriggerExpiredModal: () => void;
  focusedIndex: number;
  focusedSection: 'categories' | 'channels';
  favorites: number[];
  onToggleFavorite: (streamId: number) => void;
}

export const ChannelGuide: React.FC<ChannelGuideProps> = ({
  categories,
  channels,
  activeCategoryId,
  onSelectCategory,
  activeChannel,
  onSelectChannel,
  onOpenPlayer,
  userInfo,
  credentials,
  onLogout,
  onOpenAndroidExport,
  onTriggerExpiredModal,
  focusedIndex,
  focusedSection,
  favorites,
  onToggleFavorite,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showOnlyFavorites, setShowOnlyFavorites] = useState(false);

  // Filter channels based on search and favorites
  const filteredChannels = useMemo(() => {
    return channels.filter((ch) => {
      const matchesSearch = !searchQuery || ch.name.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesFav = !showOnlyFavorites || favorites.includes(ch.stream_id);
      return matchesSearch && matchesFav;
    });
  }, [channels, searchQuery, showOnlyFavorites, favorites]);

  // Account expiration calculation
  const expirationText = useMemo(() => {
    if (!userInfo?.exp_date) return 'Unlimited / Active';
    const num = Number(userInfo.exp_date);
    if (!isNaN(num) && num > 0) {
      return new Date(num * 1000).toLocaleDateString(undefined, {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
      });
    }
    return userInfo.exp_date;
  }, [userInfo]);

  return (
    <div className="h-screen w-full flex flex-col bg-[#070B19] text-white overflow-hidden select-none">
      {/* Top TV Bar Header */}
      <header className="h-20 shrink-0 px-6 md:px-8 border-b border-slate-800/80 bg-slate-950/60 backdrop-blur-xl flex items-center justify-between z-20">
        {/* Brand Logo & Name */}
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 rounded-2xl overflow-hidden border border-cyan-400/40 shadow-lg shadow-cyan-950/80 bg-slate-900 shrink-0">
            <img src={STREAM_VIBE_LOGO} alt="Stream Vibe" className="w-full h-full object-cover" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-xl md:text-2xl font-black tracking-tight text-white uppercase">
                Stream <span className="text-cyan-400">Vibe</span>
              </h1>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-500/30 text-cyan-300 font-bold">
                TV LEANBACK
              </span>
            </div>
            <p className="text-[11px] text-slate-400 flex items-center gap-2">
              <span>{credentials?.serverUrl || 'Xtream Engine'}</span>
              <span>•</span>
              <span className="text-purple-300 font-mono">Live Guide</span>
            </p>
          </div>
        </div>

        {/* Center Search Input */}
        <div className="hidden lg:flex items-center w-80 relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
            <Search className="w-4 h-4 text-cyan-400" />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search channels..."
            className="w-full pl-9 pr-4 py-2 bg-slate-900/80 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500/70"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-white text-xs"
            >
              ✕
            </button>
          )}
        </div>

        {/* Header Actions */}
        <div className="flex items-center space-x-3">
          {/* WhatsApp Support Direct Button */}
          <a
            href={WHATSAPP_LINK}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => tvAudio.playClick()}
            className="flex items-center space-x-1.5 py-2 px-3 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/40 text-emerald-300 text-xs font-semibold transition-all shadow-sm"
            title={`Renew / Support WhatsApp (${WHATSAPP_NUMBER})`}
          >
            <MessageCircle className="w-4 h-4 text-emerald-400" />
            <span className="hidden sm:inline">WhatsApp Help</span>
          </a>

          {/* Android Project APK Button */}
          <button
            onClick={() => { tvAudio.playClick(); onOpenAndroidExport(); }}
            className="flex items-center space-x-1.5 py-2 px-3 rounded-xl bg-gradient-to-r from-purple-900/60 to-cyan-900/60 hover:from-purple-800/80 hover:to-cyan-800/80 border border-cyan-400/40 text-cyan-200 text-xs font-bold transition-all shadow-md active:scale-95"
            title="Download Android Studio Project & APK Build Guide"
          >
            <Download className="w-4 h-4 text-cyan-300 animate-bounce" />
            <span>Android APK Build</span>
          </button>

          {/* Test Expired Button */}
          <button
            onClick={() => { tvAudio.playClick(); onTriggerExpiredModal(); }}
            className="hidden xl:flex items-center space-x-1 py-2 px-2.5 rounded-xl bg-red-950/30 hover:bg-red-900/40 border border-red-500/30 text-red-300 text-xs font-medium"
            title="Simulate Expired Subscription Screen"
          >
            <AlertCircle className="w-3.5 h-3.5 text-red-400" />
            <span>Test Expired</span>
          </button>

          {/* User Info / Logout */}
          <div className="flex items-center space-x-2 pl-2 border-l border-slate-800">
            <div className="hidden sm:block text-right">
              <p className="text-xs font-bold text-white leading-tight">{userInfo?.username || credentials?.username || 'Customer'}</p>
              <p className="text-[10px] text-slate-400">Exp: {expirationText}</p>
            </div>
            <button
              onClick={() => { tvAudio.playClick(); onLogout(); }}
              className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-850 text-slate-400 hover:text-red-400 border border-slate-800 transition-colors"
              title="Logout"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Body: Two Column TV Layout */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Column: Categories Rail (10-foot TV Nav) */}
        <aside className="w-64 md:w-72 shrink-0 border-r border-slate-800/80 bg-slate-950/40 flex flex-col overflow-y-auto custom-scrollbar">
          <div className="p-4 border-b border-slate-800/60 flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-cyan-400" />
              Categories ({categories.length})
            </span>
            <button
              onClick={() => {
                tvAudio.playClick();
                setShowOnlyFavorites(!showOnlyFavorites);
              }}
              className={`p-1.5 rounded-lg border text-xs flex items-center gap-1 ${
                showOnlyFavorites
                  ? 'bg-amber-500/20 border-amber-500/50 text-amber-300'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
              }`}
              title="Filter Favorites"
            >
              <Star className="w-3.5 h-3.5 fill-current" />
            </button>
          </div>

          <div className="p-2 space-y-1">
            {/* All Channels Option */}
            <button
              onClick={() => {
                tvAudio.playClick();
                onSelectCategory('all');
              }}
              className={`w-full text-left px-4 py-3 rounded-2xl text-xs md:text-sm font-bold flex items-center justify-between transition-all ${
                activeCategoryId === 'all'
                  ? 'bg-gradient-to-r from-cyan-500/25 to-purple-600/25 border-l-4 border-cyan-400 text-white shadow-lg shadow-cyan-950/50'
                  : 'text-slate-300 hover:bg-slate-900/60 hover:text-white'
              } ${
                focusedSection === 'categories' && focusedIndex === 0 ? 'ring-2 ring-cyan-400 bg-slate-900' : ''
              }`}
            >
              <div className="flex items-center space-x-2.5 truncate">
                <Sparkles className="w-4 h-4 text-cyan-400 shrink-0" />
                <span className="truncate">All Live Channels</span>
              </div>
              <span className="text-[10px] font-mono text-slate-400 bg-slate-900/80 px-2 py-0.5 rounded-full">
                {channels.length}
              </span>
            </button>

            {/* Category Items */}
            {categories.map((cat, idx) => {
              const isActive = activeCategoryId === cat.category_id;
              const isFocused = focusedSection === 'categories' && focusedIndex === idx + 1;
              return (
                <button
                  key={cat.category_id}
                  onClick={() => {
                    tvAudio.playClick();
                    onSelectCategory(cat.category_id);
                  }}
                  className={`w-full text-left px-4 py-3 rounded-2xl text-xs md:text-sm font-semibold flex items-center justify-between transition-all ${
                    isActive
                      ? 'bg-gradient-to-r from-cyan-500/20 to-purple-600/20 border-l-4 border-cyan-400 text-cyan-300 font-bold shadow-md'
                      : 'text-slate-400 hover:bg-slate-900/50 hover:text-slate-200'
                  } ${
                    isFocused ? 'ring-2 ring-cyan-400 bg-slate-900 scale-[1.02]' : ''
                  }`}
                >
                  <div className="flex items-center space-x-2.5 truncate">
                    <Tv className={`w-4 h-4 shrink-0 ${isActive ? 'text-cyan-400' : 'text-slate-500'}`} />
                    <span className="truncate">{cat.category_name}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </aside>

        {/* Center / Right: Channel List & Live Preview */}
        <main className="flex-1 flex flex-col md:flex-row overflow-hidden">
          {/* Channel Grid Column */}
          <div className="flex-1 flex flex-col overflow-y-auto p-4 md:p-6 custom-scrollbar">
            {/* Guide Subhead */}
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-lg font-black text-white uppercase tracking-tight flex items-center gap-2">
                  <span>
                    {activeCategoryId === 'all'
                      ? 'All Channels'
                      : categories.find((c) => c.category_id === activeCategoryId)?.category_name || 'Channels'}
                  </span>
                  <span className="text-xs font-mono text-cyan-400 bg-cyan-950/80 px-2.5 py-0.5 rounded-full border border-cyan-500/30">
                    {filteredChannels.length} Streams
                  </span>
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Select any channel to start live playback or press Enter on your remote
                </p>
              </div>

              {/* Mobile search bar */}
              <div className="lg:hidden w-40">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Filter..."
                  className="w-full px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white"
                />
              </div>
            </div>

            {/* Channels Grid */}
            {filteredChannels.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center p-12 text-center">
                <Radio className="w-12 h-12 text-slate-600 mb-3" />
                <h3 className="text-base font-bold text-slate-300">No Channels Found</h3>
                <p className="text-xs text-slate-500 max-w-sm mt-1">
                  {searchQuery
                    ? `No channels matching "${searchQuery}". Try a different keyword.`
                    : 'This category does not have any active live streams.'}
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 2xl:grid-cols-4 gap-3">
                {filteredChannels.map((channel, idx) => {
                  const isSelected = activeChannel?.stream_id === channel.stream_id;
                  const isFav = favorites.includes(channel.stream_id);
                  const isFocused = focusedSection === 'channels' && focusedIndex === idx;

                  return (
                    <div
                      key={channel.stream_id}
                      onClick={() => {
                        tvAudio.playClick();
                        onSelectChannel(channel);
                      }}
                      onDoubleClick={() => {
                        tvAudio.playSelect();
                        onOpenPlayer(channel);
                      }}
                      className={`group relative rounded-2xl p-3.5 border transition-all cursor-pointer flex flex-col justify-between ${
                        isSelected
                          ? 'bg-slate-900/90 border-cyan-400 shadow-xl shadow-cyan-950/60 ring-2 ring-cyan-400/40 scale-[1.01]'
                          : 'bg-slate-950/70 border-slate-800/80 hover:bg-slate-900/70 hover:border-slate-700'
                      } ${
                        isFocused ? 'ring-4 ring-cyan-400 border-cyan-300 scale-[1.03] shadow-2xl z-10' : ''
                      }`}
                    >
                      <div className="flex items-start space-x-3">
                        {/* Channel Logo Icon */}
                        <div className="relative w-12 h-12 rounded-xl bg-slate-900 border border-slate-800 overflow-hidden shrink-0 flex items-center justify-center shadow-inner">
                          {channel.stream_icon ? (
                            <img
                              src={channel.stream_icon}
                              alt={channel.name}
                              className="w-full h-full object-cover"
                              onError={(e) => {
                                (e.target as HTMLElement).style.display = 'none';
                              }}
                            />
                          ) : (
                            <Tv className="w-5 h-5 text-cyan-400/80" />
                          )}
                          {isSelected && (
                            <div className="absolute inset-0 bg-cyan-500/20 flex items-center justify-center">
                              <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping" />
                            </div>
                          )}
                        </div>

                        {/* Channel Title & Num */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center space-x-1.5 mb-0.5">
                            <span className="font-mono text-[10px] font-bold text-cyan-400 bg-slate-900 px-1.5 py-0.2 rounded border border-slate-800">
                              CH {channel.num || channel.stream_id}
                            </span>
                            {isSelected && (
                              <span className="text-[9px] font-extrabold text-red-400 uppercase tracking-widest bg-red-950/80 px-1 rounded">
                                LIVE
                              </span>
                            )}
                          </div>
                          <h3 className="text-xs sm:text-sm font-bold text-white group-hover:text-cyan-300 transition-colors line-clamp-2 leading-snug">
                            {channel.name}
                          </h3>
                        </div>
                      </div>

                      {/* Card Bottom Meta & Actions */}
                      <div className="flex items-center justify-between mt-3 pt-2 border-t border-slate-800/60 text-[11px]">
                        <span className="text-slate-400 truncate max-w-[120px]">
                          {channel.categoryName || 'Live'}
                        </span>

                        <div className="flex items-center space-x-1.5">
                          {/* Favorite Button */}
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              tvAudio.playClick();
                              onToggleFavorite(channel.stream_id);
                            }}
                            className={`p-1.5 rounded-lg border transition-colors ${
                              isFav
                                ? 'bg-amber-500/20 border-amber-500/40 text-amber-300'
                                : 'bg-slate-900/60 border-slate-800 text-slate-500 hover:text-amber-400'
                            }`}
                            title={isFav ? 'Remove Favorite' : 'Add Favorite'}
                          >
                            <Star className={`w-3.5 h-3.5 ${isFav ? 'fill-current' : ''}`} />
                          </button>

                          {/* Fullscreen Play Button */}
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              tvAudio.playSelect();
                              onOpenPlayer(channel);
                            }}
                            className="p-1.5 rounded-lg bg-gradient-to-tr from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-slate-950 font-bold transition-transform active:scale-90"
                            title="Watch Fullscreen"
                          >
                            <Play className="w-3.5 h-3.5 fill-current" />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Right Column: Mini Preview / Channel Details */}
          {activeChannel && (
            <div className="hidden 2xl:flex w-80 shrink-0 border-l border-slate-800/80 bg-slate-950/80 p-5 flex-col justify-between">
              <div>
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3 block">
                  Channel Preview
                </span>

                <div className="w-full aspect-video rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden relative mb-4 shadow-xl group">
                  {activeChannel.stream_icon ? (
                    <img
                      src={activeChannel.stream_icon}
                      alt={activeChannel.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-cyan-400">
                      <Tv className="w-12 h-12" />
                    </div>
                  )}
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => onOpenPlayer(activeChannel)}
                      className="p-4 rounded-full bg-cyan-400 text-slate-950 shadow-xl"
                    >
                      <Play className="w-6 h-6 fill-current ml-0.5" />
                    </button>
                  </div>
                </div>

                <div className="space-y-2">
                  <span className="text-xs font-mono font-bold text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-500/30">
                    CHANNEL {activeChannel.num || activeChannel.stream_id}
                  </span>
                  <h3 className="text-base font-extrabold text-white leading-tight">
                    {activeChannel.name}
                  </h3>
                  <p className="text-xs text-slate-400">
                    Category: {activeChannel.categoryName || 'Live Streams'}
                  </p>
                </div>
              </div>

              <div className="space-y-3 pt-4 border-t border-slate-800">
                <button
                  onClick={() => onOpenPlayer(activeChannel)}
                  className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-cyan-400 via-cyan-300 to-purple-500 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg shadow-cyan-500/30 flex items-center justify-center space-x-2 transition-transform active:scale-95"
                >
                  <Maximize2 className="w-4 h-4" />
                  <span>Watch Fullscreen (F)</span>
                </button>

                <p className="text-[10px] text-slate-500 text-center">
                  Press OK on TV Remote or Double Click card
                </p>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};
