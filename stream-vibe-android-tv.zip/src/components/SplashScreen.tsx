import React, { useEffect, useState } from 'react';
import { STREAM_VIBE_LOGO } from '../assets/logo';
import { Sparkles, Tv, ShieldCheck } from 'lucide-react';

interface SplashScreenProps {
  onFinish: () => void;
  statusMessage?: string;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({
  onFinish,
  statusMessage = 'Initializing Stream Vibe Engine...',
}) => {
  const [progress, setProgress] = useState(15);

  useEffect(() => {
    const timer1 = setTimeout(() => setProgress(55), 500);
    const timer2 = setTimeout(() => setProgress(88), 1200);
    const timer3 = setTimeout(() => {
      setProgress(100);
      setTimeout(onFinish, 400);
    }, 1800);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
    };
  }, [onFinish]);

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#070B19] select-none overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute -top-32 -left-32 w-96 h-96 rounded-full bg-cyan-500/10 blur-3xl pointer-events-none" />
      <div className="absolute -bottom-32 -right-32 w-96 h-96 rounded-full bg-purple-600/15 blur-3xl pointer-events-none" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(15,23,42,0.4)_0,rgba(7,11,25,1)_100%)] pointer-events-none" />

      {/* Main Brand Card */}
      <div className="relative z-10 flex flex-col items-center max-w-md px-6 text-center animate-in fade-in zoom-in-95 duration-700">
        {/* Logo with pulsing glow ring */}
        <div className="relative mb-6">
          <div className="absolute -inset-3 rounded-3xl bg-gradient-to-r from-cyan-500/40 via-purple-600/40 to-cyan-400/40 blur-xl opacity-75 animate-pulse" />
          <div className="relative w-36 h-36 md:w-44 md:h-44 rounded-2xl overflow-hidden border-2 border-cyan-400/50 shadow-2xl shadow-cyan-950/80 bg-slate-900">
            <img
              src={STREAM_VIBE_LOGO}
              alt="Stream Vibe Logo"
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        {/* Title & Tagline */}
        <div className="space-y-1 mb-8">
          <div className="flex items-center justify-center space-x-2">
            <span className="text-3xl md:text-4xl font-black tracking-tight text-white uppercase drop-shadow-md">
              Stream <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-purple-300 to-purple-400">Vibe</span>
            </span>
          </div>
          <div className="flex items-center justify-center space-x-2 text-xs md:text-sm font-medium text-cyan-300/80 tracking-widest uppercase">
            <Tv className="w-4 h-4 text-cyan-400" />
            <span>Android TV IPTV Player</span>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-64 md:w-72 mb-4">
          <div className="h-1.5 w-full bg-slate-800/90 rounded-full overflow-hidden border border-slate-700/50">
            <div
              className="h-full bg-gradient-to-r from-cyan-400 via-purple-500 to-cyan-300 transition-all duration-300 ease-out shadow-sm shadow-cyan-400"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="flex items-center justify-between mt-2 text-[11px] text-slate-400">
            <span className="flex items-center gap-1 font-mono">
              <Sparkles className="w-3 h-3 text-cyan-400" />
              {statusMessage}
            </span>
            <span className="font-mono text-cyan-400">{progress}%</span>
          </div>
        </div>

        {/* Bottom meta */}
        <div className="flex items-center space-x-4 text-[10px] text-slate-500 uppercase tracking-widest pt-4">
          <span className="flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-purple-400" /> Xtream Codes API
          </span>
          <span>•</span>
          <span>Media3 ExoPlayer</span>
          <span>•</span>
          <span>Android TV 14</span>
        </div>
      </div>
    </div>
  );
};
