import React, { useState } from 'react';
import { 
  AlertTriangle, 
  MessageCircle, 
  Calendar, 
  User, 
  Copy, 
  Check, 
  RefreshCw, 
  LogOut, 
  Sparkles,
  ExternalLink
} from 'lucide-react';
import { STREAM_VIBE_LOGO, WHATSAPP_NUMBER, WHATSAPP_LINK } from '../assets/logo';
import { tvAudio } from '../utils/tvAudio';

interface SubscriptionExpiredScreenProps {
  username?: string;
  expiryDate?: string | null;
  onRelogin: () => void;
  onUseDemoMode?: () => void;
}

export const SubscriptionExpiredScreen: React.FC<SubscriptionExpiredScreenProps> = ({
  username = 'Customer',
  expiryDate,
  onRelogin,
  onUseDemoMode,
}) => {
  const [copied, setCopied] = useState(false);

  // Format expiry date if present
  let formattedDate = 'Expired';
  if (expiryDate) {
    const num = Number(expiryDate);
    if (!isNaN(num) && num > 0) {
      formattedDate = new Date(num * 1000).toLocaleDateString(undefined, {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
      });
    } else {
      formattedDate = expiryDate;
    }
  }

  const customWhatsAppUrl = `https://wa.me/923491299788?text=${encodeURIComponent(
    `Hello Stream Vibe Support, I would like to renew my IPTV subscription for customer account: ${username}`
  )}`;

  const handleCopyNumber = () => {
    tvAudio.playClick();
    navigator.clipboard.writeText(WHATSAPP_NUMBER);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#070B19]/95 backdrop-blur-2xl p-4 md:p-8 select-none">
      {/* Background glow effects */}
      <div className="absolute top-1/4 left-1/4 w-80 h-80 rounded-full bg-purple-600/15 blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-80 h-80 rounded-full bg-cyan-500/10 blur-3xl pointer-events-none" />

      <div className="relative w-full max-w-2xl bg-slate-900/90 border border-purple-500/30 rounded-3xl p-6 md:p-10 shadow-2xl shadow-purple-950/60 ring-1 ring-cyan-500/20 text-white animate-in zoom-in-95 fade-in duration-300">
        {/* Top Header Badge */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-5 mb-6">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 rounded-xl overflow-hidden border border-cyan-400/50 shadow-md">
              <img src={STREAM_VIBE_LOGO} alt="Stream Vibe" className="w-full h-full object-cover" />
            </div>
            <div>
              <h2 className="text-xl font-black tracking-tight text-white uppercase">
                Stream <span className="text-cyan-400">Vibe</span>
              </h2>
              <p className="text-xs text-slate-400">Account Access Alert</p>
            </div>
          </div>

          <div className="flex items-center space-x-2 bg-red-500/15 border border-red-500/40 px-3 py-1.5 rounded-full">
            <AlertTriangle className="w-4 h-4 text-red-400 animate-pulse" />
            <span className="text-xs font-bold text-red-300 uppercase tracking-wider">Expired</span>
          </div>
        </div>

        {/* Hero Notice */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-purple-900/60 to-red-900/40 border border-purple-500/40 flex items-center justify-center mx-auto mb-4 shadow-lg shadow-purple-950/50">
            <AlertTriangle className="w-8 h-8 text-purple-300" />
          </div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight mb-2">
            Subscription Has Expired
          </h1>
          <p className="text-slate-300 text-sm md:text-base max-w-lg mx-auto">
            Your Stream Vibe IPTV plan has ended. To continue enjoying uninterrupted live TV channels, sports, and movies, please renew your subscription via our WhatsApp customer service.
          </p>
        </div>

        {/* Account Details Box */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-slate-950/70 border border-slate-800 rounded-2xl p-4 mb-6">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-cyan-400">
              <User className="w-4 h-4" />
            </div>
            <div>
              <p className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">Customer Username</p>
              <p className="text-sm font-mono font-bold text-white truncate">{username}</p>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-purple-400">
              <Calendar className="w-4 h-4" />
            </div>
            <div>
              <p className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">Expiration Status</p>
              <p className="text-sm font-mono font-bold text-red-400">{formattedDate}</p>
            </div>
          </div>
        </div>

        {/* WhatsApp Renewal Main Action */}
        <div className="space-y-3 mb-6">
          <a
            href={customWhatsAppUrl}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => tvAudio.playSelect()}
            className="w-full flex items-center justify-center space-x-3 py-4 px-6 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-white font-extrabold text-base md:text-lg shadow-xl shadow-emerald-950/70 border border-emerald-400/40 transition-all hover:scale-[1.01] active:scale-[0.99] group focus:outline-none focus:ring-4 focus:ring-emerald-400/40"
          >
            <MessageCircle className="w-6 h-6 fill-current text-white shrink-0 group-hover:scale-110 transition-transform" />
            <span>Renew on WhatsApp ({WHATSAPP_NUMBER})</span>
            <ExternalLink className="w-4 h-4 ml-1 opacity-70 group-hover:opacity-100" />
          </a>

          {/* Quick Copy Number */}
          <div className="flex items-center justify-center space-x-2 text-xs text-slate-400">
            <span>Direct WhatsApp Helpline:</span>
            <span className="font-mono font-bold text-cyan-300">{WHATSAPP_NUMBER}</span>
            <button
              onClick={handleCopyNumber}
              className="p-1 px-2 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center gap-1 transition-colors"
              title="Copy WhatsApp Number"
            >
              {copied ? (
                <>
                  <Check className="w-3 h-3 text-emerald-400" />
                  <span className="text-[11px] text-emerald-400">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3 h-3" />
                  <span className="text-[11px]">Copy</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Secondary options (Relogin or Test Demo) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3 border-t border-slate-800/80">
          <button
            onClick={() => { tvAudio.playClick(); onRelogin(); }}
            className="w-full py-2.5 px-4 rounded-xl bg-slate-800/80 hover:bg-slate-750 border border-slate-700/60 text-slate-300 hover:text-white text-xs font-semibold flex items-center justify-center space-x-2 transition-all active:scale-98"
          >
            <LogOut className="w-4 h-4 text-purple-400" />
            <span>Switch / Re-login Account</span>
          </button>

          {onUseDemoMode && (
            <button
              onClick={() => { tvAudio.playClick(); onUseDemoMode(); }}
              className="w-full py-2.5 px-4 rounded-xl bg-cyan-950/30 hover:bg-cyan-900/40 border border-cyan-500/30 text-cyan-300 hover:text-cyan-200 text-xs font-semibold flex items-center justify-center space-x-2 transition-all active:scale-98"
            >
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <span>Continue with Demo Channels</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
