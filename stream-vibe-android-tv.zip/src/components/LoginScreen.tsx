import React, { useState } from 'react';
import { 
  Server, 
  User, 
  Lock, 
  Eye, 
  EyeOff, 
  LogIn, 
  Sparkles, 
  AlertCircle, 
  ShieldCheck, 
  Tv, 
  Flame,
  Check
} from 'lucide-react';
import { STREAM_VIBE_LOGO } from '../assets/logo';
import { XtreamCredentials } from '../types/xtream';
import { tvAudio } from '../utils/tvAudio';

interface LoginScreenProps {
  onLogin: (credentials: XtreamCredentials, remember: boolean) => Promise<void>;
  isLoading: boolean;
  errorMessage: string | null;
  onClearError: () => void;
  onQuickDemo: () => void;
  onQuickExpiredTest: () => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({
  onLogin,
  isLoading,
  errorMessage,
  onClearError,
  onQuickDemo,
  onQuickExpiredTest,
}) => {
  const [serverUrl, setServerUrl] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [remember, setRemember] = useState(true);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    tvAudio.playSelect();
    if (!serverUrl.trim() || !username.trim() || !password.trim()) {
      return;
    }
    await onLogin({ serverUrl, username, password }, remember);
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-[#070B19] p-4 md:p-8 select-none relative overflow-hidden">
      {/* Background radial gradients */}
      <div className="absolute top-0 -left-20 w-96 h-96 rounded-full bg-cyan-600/10 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-0 -right-20 w-96 h-96 rounded-full bg-purple-600/15 blur-[120px] pointer-events-none" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(15,23,42,0.3)_0,rgba(7,11,25,0.95)_100%)] pointer-events-none" />

      {/* Main Login Card */}
      <div className="relative z-10 w-full max-w-lg bg-slate-900/85 backdrop-blur-xl border border-cyan-500/20 rounded-3xl p-6 sm:p-9 shadow-2xl shadow-cyan-950/70 ring-1 ring-purple-500/15">
        
        {/* Brand Header */}
        <div className="flex flex-col items-center text-center mb-6">
          <div className="relative mb-3 group">
            <div className="absolute -inset-2 rounded-2xl bg-gradient-to-r from-cyan-500/40 via-purple-600/40 to-cyan-400/40 blur-md opacity-70 group-hover:opacity-100 transition-opacity" />
            <div className="relative w-16 h-16 rounded-2xl overflow-hidden border-2 border-cyan-400/40 shadow-lg bg-slate-950">
              <img src={STREAM_VIBE_LOGO} alt="Stream Vibe" className="w-full h-full object-cover" />
            </div>
          </div>

          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white uppercase">
            Stream <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-400">Vibe</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1 flex items-center gap-1.5">
            <Tv className="w-3.5 h-3.5 text-cyan-400" />
            <span>Xtream Codes IPTV Player • Android TV Edition</span>
          </p>
        </div>

        {/* Error Alert Banner */}
        {errorMessage && (
          <div className="mb-5 p-3.5 rounded-2xl bg-red-950/40 border border-red-500/40 text-red-200 text-xs sm:text-sm flex items-start space-x-3 animate-in fade-in duration-200">
            <AlertCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
            <div className="flex-1">
              <span className="font-semibold block text-red-300">Connection Error</span>
              <span className="text-slate-300">{errorMessage}</span>
            </div>
            <button
              onClick={onClearError}
              className="text-slate-400 hover:text-white text-xs font-bold px-1"
            >
              ✕
            </button>
          </div>
        )}

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Server URL */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Server URL
            </label>
            <div className="relative rounded-xl overflow-hidden focus-within:ring-2 focus-within:ring-cyan-400/80 transition-all">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <Server className="w-4 h-4 text-cyan-400" />
              </div>
              <input
                type="text"
                value={serverUrl}
                onChange={(e) => { onClearError(); setServerUrl(e.target.value); }}
                placeholder="http://your-iptv-server.com:8080"
                className="w-full pl-10 pr-4 py-3 bg-slate-950/80 border border-slate-800 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-500/60 rounded-xl"
                required
                autoComplete="url"
              />
            </div>
            <span className="text-[10px] text-slate-500 mt-1 block">Include protocol and port (http:// or https://)</span>
          </div>

          {/* Username */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Username
            </label>
            <div className="relative rounded-xl overflow-hidden focus-within:ring-2 focus-within:ring-cyan-400/80 transition-all">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <User className="w-4 h-4 text-purple-400" />
              </div>
              <input
                type="text"
                value={username}
                onChange={(e) => { onClearError(); setUsername(e.target.value); }}
                placeholder="Customer username"
                className="w-full pl-10 pr-4 py-3 bg-slate-950/80 border border-slate-800 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-500/60 rounded-xl"
                required
                autoComplete="username"
              />
            </div>
          </div>

          {/* Password */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Password
            </label>
            <div className="relative rounded-xl overflow-hidden focus-within:ring-2 focus-within:ring-cyan-400/80 transition-all">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <Lock className="w-4 h-4 text-cyan-400" />
              </div>
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => { onClearError(); setPassword(e.target.value); }}
                placeholder="••••••••••••"
                className="w-full pl-10 pr-10 py-3 bg-slate-950/80 border border-slate-800 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-500/60 rounded-xl"
                required
                autoComplete="current-password"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-200 transition-colors"
                tabIndex={-1}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Remember credentials check */}
          <div className="flex items-center justify-between pt-1">
            <label className="flex items-center space-x-2 text-xs text-slate-400 cursor-pointer">
              <input
                type="checkbox"
                checked={remember}
                onChange={(e) => setRemember(e.target.checked)}
                className="rounded border-slate-700 text-cyan-500 focus:ring-0 focus:outline-none bg-slate-950"
              />
              <span>Remember login on this TV</span>
            </label>
            <span className="text-[10px] text-slate-500 flex items-center gap-1">
              <ShieldCheck className="w-3 h-3 text-cyan-400" /> Stored locally only
            </span>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 via-cyan-400 to-purple-600 hover:from-cyan-400 hover:to-purple-500 active:scale-[0.99] text-slate-950 font-extrabold text-sm tracking-wide uppercase transition-all shadow-lg shadow-cyan-500/25 flex items-center justify-center space-x-2 disabled:opacity-60 cursor-pointer focus:outline-none focus:ring-2 focus:ring-cyan-300"
          >
            {isLoading ? (
              <>
                <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                <span>Connecting to Server...</span>
              </>
            ) : (
              <>
                <LogIn className="w-4 h-4" />
                <span>Connect & Load Channels</span>
              </>
            )}
          </button>
        </form>

        {/* Quick Testing Badges */}
        <div className="mt-6 pt-5 border-t border-slate-800 space-y-2">
          <p className="text-[11px] text-slate-400 text-center font-medium">Quick Preview & Testing Controls</p>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => { tvAudio.playClick(); onQuickDemo(); }}
              className="py-2.5 px-3 rounded-xl bg-cyan-950/40 hover:bg-cyan-900/50 border border-cyan-500/30 text-cyan-300 text-xs font-semibold flex items-center justify-center space-x-1.5 transition-all active:scale-95 group"
            >
              <Sparkles className="w-3.5 h-3.5 text-cyan-400 group-hover:scale-110 transition-transform" />
              <span>Launch Demo Channels</span>
            </button>

            <button
              type="button"
              onClick={() => { tvAudio.playClick(); onQuickExpiredTest(); }}
              className="py-2.5 px-3 rounded-xl bg-purple-950/40 hover:bg-purple-900/50 border border-purple-500/30 text-purple-300 text-xs font-semibold flex items-center justify-center space-x-1.5 transition-all active:scale-95 group"
            >
              <Flame className="w-3.5 h-3.5 text-purple-400 group-hover:scale-110 transition-transform" />
              <span>Test Expired Alert</span>
            </button>
          </div>
        </div>

        {/* Security Notice */}
        <div className="mt-4 text-center">
          <p className="text-[10px] text-slate-500">
            Never hardcoded: Each customer enters their own provider credentials directly.
          </p>
        </div>
      </div>
    </div>
  );
};
